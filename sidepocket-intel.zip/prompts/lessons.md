# What the desk learned

You are writing down what each analyst should carry forward. Read
`data/memory/_pending.json`. It holds, for every analyst with new evidence:

- `record` — arithmetic over their own history: hit rate by horizon class, whether their
  stated confidence ran hot or cold, how many setups never fired, how often they conceded
  or were ruled against, and the outcome of each settled call.
- `existing_lessons` — what they already carry. Do not restate these.
- `new_evidence` — the anchors: calls that settled, rulings the Auditor made against them,
  positions they withdrew.

## What a lesson is
A lesson is a **specific, behavioural correction an analyst can apply next round**, drawn
from something that actually happened to them.

Good: "My swing calls work and my position calls do not — 2 of 3 against 0 of 2. Stop
filing multi-week theses I cannot check weekly."

Good: "I said 0.35 on a call that hit +1.89R. I was right and underpaid for it because I
would not commit. Say the number I believe."

Bad: "I should continue to be rigorous and evidence-based." — true of everyone, changes
nothing.

Bad: "The market is volatile." — not about this analyst.

Bad: any lesson drawn from a call that is still open. Nothing has been learned yet.

## The rule that matters
Every lesson must cite an `anchor` — the id of the call, ruling or concession it came
from. **The runner checks that anchor exists and belongs to that analyst, and silently
drops the lesson if it does not.** A lesson you cannot anchor is an opinion about someone,
and this file is not for opinions.

Where the evidence genuinely supports nothing yet, write no lesson for that analyst. One
settled call is not a pattern. Saying nothing is a valid and often correct answer.

## Be specific about the mechanism
"I was wrong about MP" is not a lesson. *Why* it went wrong is:
- was the thesis wrong, or right but early?
- was the entry zone unreachable, so it never fired?
- was the stop too tight for how that name moves?
- did they ignore a document that was on file?
- did the Auditor catch them asserting something they could not show?

## Output — write only `data/memory/_lessons.json`

```json
{
  "lessons": {
    "contra": [
      {"text": "one or two sentences, in their own voice, about what to do differently",
       "anchor": "<id from new_evidence>",
       "kind": "calibration | sizing | horizon | evidence | discipline"}
    ]
  },
  "considered": {
    "macro": ["<anchor id I read but drew no lesson from>"]
  }
}
```

At most **two** lessons per analyst, and fewer is usually right. Put anchors you read but
learned nothing from in `considered`, so nobody is shown them again.
