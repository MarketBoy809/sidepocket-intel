# Sidepocket — setup handoff (for Claude running on the owner's PC)

The owner (GitHub user **MarketBoy809**) wants you to do all GitHub work for him. He should only
need to approve a GitHub sign-in if asked, and tap Install on his Android phone at the end.
Everything below was built and tested in an earlier session; do not rewrite the code.

## Files (in the owner's Downloads folder)
- `sidepocket-intel.zip` — the market-intel collector (this file came from inside it).
- `Sidepocket-android.zip` — v2 of the Android app (hub + widget).
Extract `sidepocket-intel.zip` somewhere temporary to read `setup/`.

## Tools
Use git and the GitHub CLI (`gh`). If `gh` is missing, install it (`winget install GitHub.cli`),
then `gh auth login --web` (the owner approves in the browser). Check `gh auth status` first.

## Task A — create the intel repo
1. `gh repo create MarketBoy809/sidepocket-intel --public --add-readme` (skip if it already exists).
2. Clone it. Put the **zip file itself** (`sidepocket-intel.zip`, not its extracted contents) in the repo root.
3. Put `setup/intel-workflow.yml` at `.github/workflows/intel.yml`.
4. Commit and push to `main`.
5. `gh workflow run Intel -R MarketBoy809/sidepocket-intel -f task=backfill`, then watch with
   `gh run watch`. It takes ~5–15 min. Success = a `data/` folder appears in the repo.
   If it fails, read `gh run view --log-failed` and fix only what's broken.

The workflow unzips the code on each run, collects hourly, and writes an AI briefing every 4 hours.

## Task B — update the app repo
1. Find the owner's existing app repo: `gh repo list MarketBoy809` — it's the one whose root contains
   a `Sidepocket-android*.zip` and a workflow that builds an APK (the name starts with "Sidepocket").
2. Clone it, **delete the old zip**, add the new `Sidepocket-android.zip` in the repo root, commit, push.
   Do not touch its workflow files.
3. Watch the build (`gh run watch`). Success = a new GitHub Release with `Sidepocket.apk`.
4. Tell the owner: on the phone, open the repo's Releases page and install the newest Sidepocket.apk.

## Task C — connect his Claude subscription (for the AI briefings)
1. Run `claude setup-token` (Claude Code must be installed; he has a Pro/Max plan). He may need to
   approve in the browser. It prints a long-lived token.
2. `gh secret set CLAUDE_CODE_OAUTH_TOKEN -R MarketBoy809/sidepocket-intel` and paste the token via stdin.
   Never print the token in chat or commit it anywhere.
3. Test: `gh workflow run Intel -R MarketBoy809/sidepocket-intel -f task=briefing` and watch it.
   Success = `data/briefing.json` appears.

## Done
Report in plain language: intel repo live (link), backfill done, app build done (Releases link),
briefings connected. Keep it short; the owner prefers to be addressed as "Sir".
