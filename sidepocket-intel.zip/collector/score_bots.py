"""Settle the desk's trade plans against what the market actually did.

Without this the ranking is decoration: calls accumulate, nothing resolves, and
every hit rate stays blank. Settlement is arithmetic - no judgement, no wriggle
room, and never by the bot that made the call.

A call is a plan, so it settles in two stages:

  open     price has not yet entered the entry zone
  armed    price entered the zone; the trade is live from that price
  hit      target reached before the stop
  miss     stop hit first
  expired  valid_days passed without ever arming

`expired` is deliberately not a miss. A setup that never triggered cost nothing
and was never wrong - punishing it would teach the desk to chase price. It is
tracked separately so the Chair can still see who writes setups that never fire.

Settling on closes rather than intraday extremes is deliberate: a wick through a
level that closes back the other side was never actionable.
"""
import json
import os
import sys

import bot_stats
import equities
from common import iso, load_json, log, now_ts, path, save_json

PREDICTIONS = path("bots", "predictions.jsonl")
REFRESH_AFTER = 6 * 3600

# how old the prices behind a live call may be before they are refetched
FRESHNESS = {
    "intraday": 15 * 60,
    "swing": 60 * 60,
    "position": 6 * 3600,
    "trend": 12 * 3600,
}


def bars(ticker, start_ts, end_ts, horizon_class=None):
    """(timestamp, close) pairs between two moments, at a resolution that suits
    the call. A few-hour call settled on daily closes would be invisible: it
    could arm and hit its target inside one bar and leave no trace."""
    snap = load_json(path("equities", "%s.json" % ticker))
    if not snap:
        return []
    s = equities.series_for(snap, horizon_class)
    if not s or not s.get("t"):
        return []
    return [(t, s["c"][i]) for i, t in enumerate(s["t"]) if start_ts <= t <= end_ts]


def spot(ticker):
    """Latest known price, from the freshest series we hold. During the session
    the 5-minute bars are hours ahead of the daily close."""
    snap = load_json(path("equities", "%s.json" % ticker))
    if not snap:
        return None
    fresh = equities._freshest(snap)
    if fresh:
        return float(fresh)
    return float(snap["price"]) if snap.get("price") else None


def _settle_legacy(call, now):
    """Pre-trade-plan calls: direction, percentage, horizon. No stop, so no
    R-multiple - they are scored on whether the move happened, nothing more."""
    entry = float(call["entry_price"])
    up = call.get("direction") != "down"
    pct = abs(float(call["target_pct"]))
    level = entry * (1 + pct / 100.0) if up else entry * (1 - pct / 100.0)
    eps = abs(level) * 1e-9
    end = call["ts"] + int(call["horizon_days"]) * 86400
    series = bars(call["ticker"], call["ts"], min(now, end), call.get("horizon_class"))
    closes = [c for _t, c in series]

    reached = (any(c >= level - eps for c in closes) if up
               else any(c <= level + eps for c in closes))
    if reached:
        call["status"] = "hit"
        call["resolved_ts"] = now
        best = max(closes) if up else min(closes)
        call["actual_pct"] = round((best - entry) / entry * 100, 2)
        call["outcome"] = "reached %.2f" % level
        return call, True
    if now >= end:
        call["status"] = "miss"
        call["resolved_ts"] = end
        if closes:
            best = max(closes) if up else min(closes)
            call["actual_pct"] = round((best - entry) / entry * 100, 2)
            call["outcome"] = "best close %.2f, needed %.2f" % (best, level)
        else:
            call["outcome"] = "no price data in the window"
        return call, True
    last = spot(call["ticker"])
    if last:
        moved = (last - entry) / entry * 100
        call["progress_pct"] = round(moved if up else -moved, 2)
        call["last_price"] = round(last, 4)
        call["needs_pct"] = round(pct - (moved if up else -moved), 2)
        return call, True
    return call, False


def settle(call, now=None):
    """Advance one call as far as the price history allows. Returns (call, changed)."""
    if call.get("status") in ("hit", "miss", "expired", "void", "withdrawn"):
        return call, False
    now = now or now_ts()

    zone = call.get("entry_zone") or []
    if len(zone) != 2 or not call.get("stop") or not call.get("target"):
        # Calls made before trade plans existed carry only a direction, a
        # percentage and a horizon. Settle those on the terms they were made
        # under rather than voiding them - and never invent a stop they did
        # not set.
        if call.get("target_pct") and call.get("entry_price") and call.get("horizon_days"):
            return _settle_legacy(call, now)
        call["status"] = "void"
        call["resolved_ts"] = now
        call["outcome"] = "incomplete plan"
        return call, True

    cls = call.get("horizon_class") or "swing"
    lo, hi = float(zone[0]), float(zone[1])
    stop, target = float(call["stop"]), float(call["target"])
    up = call.get("direction") != "down"
    eps = max(abs(target), abs(stop)) * 1e-9
    deadline = call["ts"] + int(call.get("valid_days", 10)) * 86400

    changed = False
    armed_ts = call.get("armed_ts")

    # --- stage one: did price ever enter the entry zone before the deadline? ---
    if not armed_ts:
        for ts, c in bars(call["ticker"], call["ts"], min(now, deadline), cls):
            if lo - eps <= c <= hi + eps:
                armed_ts = ts
                call["armed_ts"] = ts
                call["entry_price"] = round(c, 4)
                call["status"] = "armed"
                changed = True
                break
        if not armed_ts:
            if now >= deadline:
                call["status"] = "expired"
                call["resolved_ts"] = deadline
                call["outcome"] = "never entered the %.2f-%.2f zone" % (lo, hi)
                return call, True
            # still waiting - how far price sits from the zone, so the board can
            # sort by what is closest to actionable
            last = spot(call["ticker"])
            if last:
                edge = hi if up else lo
                call["distance_pct"] = round((last - edge) / edge * 100, 2)
                call["last_price"] = round(last, 4)
                call["in_zone"] = lo - eps <= last <= hi + eps
                changed = True
            return call, changed

    # --- stage two: target or stop first, from the moment it armed ---
    entry = float(call.get("entry_price") or (lo + hi) / 2)
    for ts, c in bars(call["ticker"], armed_ts, now, cls):
        if ts <= armed_ts:
            continue
        hit_target = (c >= target - eps) if up else (c <= target + eps)
        hit_stop = (c <= stop + eps) if up else (c >= stop - eps)
        if hit_target or hit_stop:
            call["status"] = "hit" if hit_target else "miss"
            call["resolved_ts"] = ts
            call["exit_price"] = round(c, 4)
            risk = abs(entry - stop) or 1e-9
            gain = (c - entry) if up else (entry - c)
            call["r_multiple"] = round(gain / risk, 2)
            call["actual_pct"] = round((gain / entry) * 100, 2)
            call["held_days"] = round((ts - armed_ts) / 86400.0, 1)
            call["outcome"] = ("target %.2f reached" % target if hit_target
                               else "stopped out at %.2f" % stop)
            return call, True

    # armed but undecided: show progress in R, which is what a trader watches
    live = bars(call["ticker"], armed_ts, now, cls)
    if live:
        last = live[-1][1]
        risk = abs(entry - stop) or 1e-9
        gain = (last - entry) if up else (entry - last)
        call["r_multiple"] = round(gain / risk, 2)
        call["last_price"] = round(last, 4)
        changed = True
    return call, changed


def main():
    if not os.path.exists(PREDICTIONS):
        log("no calls to settle")
        return 0
    calls = bot_stats.read_jsonl(PREDICTIONS)
    if not calls:
        log("no calls to settle")
        return 0

    # A six-hour-old price cannot settle a call measured in hours, so how stale
    # we tolerate depends on the fastest live call on that name.
    stale_after = {}
    for c in calls:
        if c.get("status") not in ("open", "armed"):
            continue
        cls = c.get("horizon_class") or "swing"
        limit = FRESHNESS.get(cls, REFRESH_AFTER)
        t = c["ticker"]
        stale_after[t] = min(stale_after.get(t, limit), limit)

    for t in sorted(stale_after):
        snap = load_json(path("equities", "%s.json" % t))
        age = now_ts() - (snap or {}).get("updated_ts", 0)
        if not snap or age > stale_after[t]:
            log("refreshing %s (%dm old, needs %dm)"
                % (t, age // 60, stale_after[t] // 60))
            equities.snapshot(t, force=True)

    settled = 0
    for i, c in enumerate(calls):
        before = c.get("status")
        calls[i], did = settle(c)
        if did and calls[i].get("status") != before:
            settled += 1
            log("%-9s %-5s %-8s %s -> %s (%s)"
                % (c["bot"], c["ticker"], c.get("horizon_class", "?"), before,
                   calls[i]["status"], calls[i].get("outcome", "")))

    with open(PREDICTIONS, "w", encoding="utf-8") as f:
        for c in calls:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")

    scores = bot_stats.compute()
    g = scores["group"]
    log("settled %d; desk %s of %s resolved, %s armed, %s waiting"
        % (settled, g.get("hit_rate"), g.get("resolved"), g.get("armed"), g.get("open_calls")))
    save_json(path("bots", "last_scored.json"),
              {"at": iso(), "settled": settled, "open": g.get("open_calls")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
