"""Settle the desk's predictions against what the market actually did.

Without this the ranking is decoration: calls accumulate, nothing resolves, and
every hit rate stays blank. A call is settled purely arithmetically - no
judgement, no wriggle room, and never by the bot that made it.

  up    hits if any close in the window reaches entry * (1 + target)
  down  hits if any close in the window falls to entry * (1 - target)
  neither, by the horizon -> miss

Settling on closes rather than intraday highs is deliberate: a wick through the
level that closes back below it is not a move anyone could have acted on.
"""
import json
import os
import sys

import bot_stats
import equities
from common import iso, load_json, log, now_ts, path, save_json

PREDICTIONS = path("bots", "predictions.jsonl")
REFRESH_AFTER = 6 * 3600


def window_closes(ticker, start_ts, end_ts):
    """Closes between two moments, from the stored series."""
    snap = load_json(path("equities", "%s.json" % ticker))
    s = (snap or {}).get("series")
    if not s or not s.get("t"):
        return []
    return [s["c"][i] for i, t in enumerate(s["t"]) if start_ts <= t <= end_ts]


def settle(pred, now=None):
    """Returns the prediction with status resolved, or unchanged if still open."""
    if pred.get("status") != "open":
        return pred, False
    now = now or now_ts()
    entry = pred.get("entry_price")
    if not entry:
        pred["status"] = "void"
        pred["resolved_ts"] = now
        pred["outcome"] = "no entry price recorded"
        return pred, True

    horizon_end = pred["ts"] + pred["horizon_days"] * 86400
    target_pct = float(pred.get("target_pct") or 0)
    up = pred.get("direction") != "down"
    level = entry * (1 + target_pct / 100.0) if up else entry * (1 - target_pct / 100.0)

    # entry * (1 + 10/100) is 110.00000000000001, so a close of exactly 110 would
    # score as a miss. A hair of tolerance keeps the arithmetic honest.
    eps = abs(level) * 1e-9
    closes = window_closes(pred["ticker"], pred["ts"], min(now, horizon_end))
    reached = (any(c >= level - eps for c in closes) if up
               else any(c <= level + eps for c in closes))

    if reached:
        pred["status"] = "hit"
        pred["resolved_ts"] = now
        best = (max(closes) if up else min(closes))
        pred["actual_pct"] = round((best - entry) / entry * 100, 2)
        pred["outcome"] = "reached %.2f" % level
        return pred, True

    if now >= horizon_end:
        pred["status"] = "miss"
        pred["resolved_ts"] = horizon_end
        if closes:
            best = (max(closes) if up else min(closes))
            pred["actual_pct"] = round((best - entry) / entry * 100, 2)
            pred["outcome"] = ("best close was %.2f, needed %.2f" % (best, level))
        else:
            pred["outcome"] = "no price data in the window"
        return pred, True

    # still live - record how far it has travelled so the app can show progress
    if closes:
        last = closes[-1]
        moved = (last - entry) / entry * 100
        pred["progress_pct"] = round(moved if up else -moved, 2)
    return pred, False


def main():
    if not os.path.exists(PREDICTIONS):
        log("no predictions to settle")
        return 0
    preds = bot_stats.read_jsonl(PREDICTIONS)
    if not preds:
        log("no predictions to settle")
        return 0

    # make sure every live call has fresh prices behind it
    live = {p["ticker"] for p in preds if p.get("status") == "open"}
    for t in sorted(live):
        snap = load_json(path("equities", "%s.json" % t))
        if not snap or now_ts() - snap.get("updated_ts", 0) > REFRESH_AFTER:
            log("refreshing", t)
            equities.snapshot(t, force=True)

    changed = 0
    for i, p in enumerate(preds):
        preds[i], did = settle(p)
        if did:
            changed += 1
            log("%-9s %-5s %-4s -> %s (%s)"
                % (p["bot"], p["ticker"], p["direction"], p["status"], p.get("outcome", "")))

    with open(PREDICTIONS, "w", encoding="utf-8") as f:
        for p in preds:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    scores = bot_stats.compute()
    g = scores["group"]
    log("settled %d; desk now %s of %s resolved, trend %s"
        % (changed, g.get("hit_rate"), g.get("resolved"), g.get("hit_rate_trend")))
    save_json(path("bots", "last_scored.json"),
              {"at": iso(), "settled": changed, "open": g.get("open_calls")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
