"""One-off (re-runnable) history download: years of prices, Fear & Greed since 2018,
every market-relevant Trump post, GDELT news tone, and a daily composite sentiment history."""
import time
from datetime import datetime, timezone

from common import SYMS, load_json, log, now_ts, path, save_json
import sources as src
import series as ser

LISTED = {"BTC": "2015-07-21", "ETH": "2016-05-19", "SOL": "2021-06-02"}


def ts_of(day):
    return int(datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())


def main():
    now = now_ts()
    for s in SYMS:
        log("daily prices", s)
        ser.update_series(s, ser.DAY, first_start=ts_of(LISTED[s]))
        log("hourly prices", s)
        ser.update_series(s, ser.HOUR, first_start=now - 730 * 86400)

    log("fear & greed history")
    fng = src.fear_greed(limit=0)
    if fng:
        save_json(path("sentiment", "fng_daily.json"), [list(r) for r in fng])

    log("truth social archive")
    posts = src.truth_posts()
    if posts:
        save_json(path("items", "truth_relevant.json"), posts)

    log("gdelt tone history (daily, since 2017)")
    tone = {}
    year = 2017
    this_year = time.gmtime(now).tm_year
    while year <= this_year:
        rows = src.gdelt_tone(src.Q_CRYPTO, start="%d0101000000" % year, end="%d1231235959" % year)
        for ts, v in rows:
            tone[(ts // 86400) * 86400] = v
        year += 1
    if tone:
        save_json(path("sentiment", "news_tone_daily.json"), sorted([k, round(v, 3)] for k, v in tone.items()))

    log("daily composite history")
    btc = load_json(ser.series_file("BTC", ser.DAY))
    fng_rows = load_json(path("sentiment", "fng_daily.json"), []) or []
    out = []
    if btc and btc.get("c"):
        closes, t0 = btc["c"], btc["t0"]
        for ts, val, _lbl in fng_rows:
            day = (ts // 86400) * 86400
            i = (day - t0) // 86400
            m = None
            if 7 <= i < len(closes):
                a, b = closes[i - 7], closes[i]
                m = (b - a) / a if a else None
            comp = ser.components(val, m, tone.get(day))
            out.append([day, ser.composite(comp)])
    save_json(path("history", "composite_daily.json"), out)
    import analyze
    analyze.main()
    log("backfill complete")


if __name__ == "__main__":
    main()
