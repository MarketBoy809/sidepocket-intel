"""Free data sources. Every fetcher is best-effort: on failure it logs and returns None/[]."""
import json
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import quote

from common import SYMS, http, http_json, item_id, log, now_ts, strip_html, tags_for, is_relevant

KRAKEN_KEYS = {"BTC": "XXBTZUSD", "ETH": "XETHZUSD", "SOL": "SOLUSD"}
COINBASE_PRODUCTS = {"BTC": "BTC-USD", "ETH": "ETH-USD", "SOL": "SOL-USD"}


# ---- prices ----------------------------------------------------------------
def kraken_ticker():
    try:
        res = http_json("https://api.kraken.com/0/public/Ticker?pair=XBTUSD,ETHUSD,SOLUSD")
        if res.get("error"):
            raise RuntimeError(res["error"])
        out = {}
        for s in SYMS:
            t = res["result"][KRAKEN_KEYS[s]]
            out[s] = {
                "p": float(t["c"][0]), "o": float(t["o"]),
                "h": float(t["h"][1]), "l": float(t["l"][1]), "v": float(t["v"][1]),
            }
        return out
    except Exception as e:  # noqa: BLE001
        log("kraken ticker failed:", e)
        return None


def coinbase_candles(sym, granularity, start_ts, end_ts):
    """Closes for [start_ts, end_ts), one entry per granularity step, oldest first.
    Returns list of (ts, close). Pages 300 candles per request (Coinbase limit)."""
    prod = COINBASE_PRODUCTS[sym]
    out = {}
    step = granularity * 300
    t = start_ts
    while t < end_ts:
        t2 = min(t + step, end_ts)
        url = ("https://api.exchange.coinbase.com/products/%s/candles?granularity=%d&start=%s&end=%s"
               % (prod, granularity, _iso(t), _iso(t2)))
        try:
            rows = http_json(url, retries=3)
            for r in rows:  # [time, low, high, open, close, volume]
                out[int(r[0])] = float(r[4])
        except Exception as e:  # noqa: BLE001
            log("coinbase", sym, granularity, "page failed:", e)
        t = t2
        time.sleep(0.25)
    return sorted(out.items())


def _iso(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---- sentiment -------------------------------------------------------------
def fear_greed(limit=1):
    """limit=0 returns full history. List of (ts, value, label), oldest first."""
    try:
        d = http_json("https://api.alternative.me/fng/?limit=%d&format=json" % limit)
        rows = [(int(x["timestamp"]), int(x["value"]), x.get("value_classification", "")) for x in d.get("data", [])]
        return sorted(rows)
    except Exception as e:  # noqa: BLE001
        log("fear&greed failed:", e)
        return []


# ---- news (GDELT) ----------------------------------------------------------
GDELT = "https://api.gdeltproject.org/api/v2/doc/doc"
Q_CRYPTO = "(bitcoin OR cryptocurrency OR ethereum OR solana OR stablecoin) sourcelang:english"
Q_GOV = ('("White House" OR Treasury OR Bessent OR "Securities and Exchange Commission" OR CFTC OR Senate '
         'OR Congress OR "European Central Bank" OR "People\'s Bank of China" OR "Bank of Japan") '
         '(crypto OR bitcoin OR stablecoin OR tariff OR "interest rates") sourcelang:english')
Q_INST = ('(BlackRock OR Fidelity OR Vanguard OR JPMorgan OR "Goldman Sachs" OR "Morgan Stanley" OR Citadel '
          'OR MicroStrategy OR Saylor OR "sovereign wealth fund") (bitcoin OR crypto OR ETF) sourcelang:english')
Q_WORLD = ('("federal reserve" OR tariff OR tariffs OR sanctions OR inflation OR "interest rates" '
           'OR ceasefire OR missile) sourcelang:english')


def _gdelt(params):
    url = GDELT + "?" + "&".join("%s=%s" % (k, quote(str(v))) for k, v in params.items())
    raw = http(url, retries=2, pause=6.0).decode("utf-8", "replace")
    time.sleep(6)  # GDELT asks for at most one request every ~5 s
    return json.loads(raw) if raw.strip().startswith("{") else {}


def _gdelt_ts(s):
    try:
        return int(datetime.strptime(s, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc).timestamp())
    except Exception:  # noqa: BLE001
        return now_ts()


def gdelt_articles(query, timespan="3h", maxrecords=60, topic=None, group="news"):
    try:
        d = _gdelt({"query": query, "mode": "ArtList", "format": "json", "timespan": timespan,
                    "maxrecords": maxrecords, "sort": "HybridRel"})
        items = []
        for a in d.get("articles", []):
            title = strip_html(a.get("title", ""))
            if not title:
                continue
            tags = tags_for(title)
            if topic and topic not in tags:
                tags.append(topic)
            items.append({
                "id": item_id(a.get("url"), title), "ts": _gdelt_ts(a.get("seendate", "")),
                "source": "news", "group": group, "kind": "news", "title": title, "url": a.get("url"),
                "domain": a.get("domain", ""), "tags": tags,
            })
        return items
    except Exception as e:  # noqa: BLE001
        log("gdelt articles failed:", e)
        return []


def gdelt_tone(query, timespan=None, start=None, end=None):
    """Average-tone timeline: list of (ts, tone)."""
    params = {"query": query, "mode": "TimelineTone", "format": "json"}
    if timespan:
        params["timespan"] = timespan
    if start:
        params["startdatetime"] = start
    if end:
        params["enddatetime"] = end
    try:
        d = _gdelt(params)
        out = []
        for series in d.get("timeline", []):
            for p in series.get("data", []):
                out.append((_gdelt_ts(p.get("date", "")), float(p.get("value", 0))))
        return sorted(out)
    except Exception as e:  # noqa: BLE001
        log("gdelt tone failed:", e)
        return []


# ---- Trump / Truth Social ----------------------------------------------------
TRUTH_URL = "https://ix.cnn.io/data/truth-social/truth_archive.json"


def _parse_time(s):
    s = (s or "").replace("Z", "+00:00")
    try:
        return int(datetime.fromisoformat(s).timestamp())
    except Exception:  # noqa: BLE001
        return None


def truth_posts(since_ts=None):
    """Market-relevant Trump posts (tariffs, Fed, crypto, war, trade...). Newest first."""
    try:
        raw = http(TRUTH_URL, timeout=90, retries=2)
        data = json.loads(raw.decode("utf-8", "replace"))
        rows = data if isinstance(data, list) else data.get("posts", data.get("data", []))
        out = []
        for p in rows:
            ts = _parse_time(p.get("created_at"))
            if ts is None or (since_ts and ts < since_ts):
                continue
            text = strip_html(p.get("content") or p.get("text") or "")
            if len(text) < 12 or not is_relevant(text):
                continue
            url = p.get("url") or ("https://truthsocial.com/@realDonaldTrump/%s" % p.get("id"))
            out.append({
                "id": item_id(url, text), "ts": ts, "source": "truth", "group": "government", "kind": "post",
                "org": "Donald Trump (Truth Social)",
                "title": text[:280], "url": url, "domain": "truthsocial.com",
                "tags": tags_for(text), "author": "Donald Trump",
                "score": int(p.get("favourites_count") or 0) + int(p.get("reblogs_count") or 0),
            })
        out.sort(key=lambda x: -x["ts"])
        return out
    except Exception as e:  # noqa: BLE001
        log("truth social failed:", e)
        return []


# ---- Official & institutional feeds (RSS/Atom) --------------------------------
# group: government | central_bank | regulator | institution | news
# The SEC's fair-access policy requires a contact e-mail in the User-Agent and
# rejects anything else (including users.noreply.github.com) with a 403.
SEC_UA = {"User-Agent": "Sidepocket-Intel marketboy809@gmail.com"}
EDGAR = ("https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=%s&type=8-K"
         "&dateb=&owner=include&count=10&output=atom")
RSS_FEEDS = [
    # United States government
    {"org": "White House", "group": "government", "url": "https://www.whitehouse.gov/news/feed/"},
    {"org": "US Labor Statistics (CPI/jobs)", "group": "government", "url": "https://www.bls.gov/feed/bls_latest.rss"},
    # Regulators
    {"org": "SEC", "group": "regulator", "url": "https://www.sec.gov/news/pressreleases.rss", "headers": SEC_UA},
    {"org": "CFTC", "group": "regulator", "url": "https://www.cftc.gov/RSS/RSSGP/rssgp.xml"},
    # Central banks
    {"org": "Federal Reserve", "group": "central_bank", "url": "https://www.federalreserve.gov/feeds/press_all.xml"},
    {"org": "European Central Bank", "group": "central_bank", "url": "https://www.ecb.europa.eu/rss/press.html"},
    {"org": "Bank of England", "group": "central_bank", "url": "https://www.bankofengland.co.uk/rss/news"},
    {"org": "Bank of Japan", "group": "central_bank", "url": "https://www.boj.or.jp/en/rss/whatsnew.xml"},
    {"org": "BIS", "group": "central_bank", "url": "https://www.bis.org/doclist/all_pressrels.rss"},
    # Big money: official filings of the largest corporate bitcoin holders / venues
    {"org": "Strategy (MSTR) filings", "group": "institution", "url": EDGAR % "0001050446", "headers": SEC_UA},
    {"org": "Coinbase filings", "group": "institution", "url": EDGAR % "0001679788", "headers": SEC_UA},
    # Crypto press
    {"org": "CoinDesk", "group": "news", "url": "https://www.coindesk.com/arc/outboundfeeds/rss/"},
    {"org": "Cointelegraph", "group": "news", "url": "https://cointelegraph.com/rss"},
    {"org": "Decrypt", "group": "news", "url": "https://decrypt.co/feed"},
]


def rss(feed, since_ts):
    """Returns (items, error). Items carry the publishing organisation and its group."""
    org, group = feed["org"], feed["group"]
    try:
        root = ET.fromstring(http(feed["url"], headers=feed.get("headers"), timeout=25))
        out = []
        for it in root.iter():
            tag0 = it.tag.split("}")[-1].lower()
            if tag0 not in ("item", "entry"):
                continue
            title = link = when = None
            for c in it:
                tag = c.tag.split("}")[-1].lower()
                if tag == "title":
                    title = strip_html(c.text or "")
                elif tag == "link" and not link:
                    link = (c.text or c.attrib.get("href") or "").strip()
                elif tag in ("pubdate", "published", "updated", "date") and not when:
                    when = c.text
            if not title or not link:
                continue
            ts = None
            try:
                ts = int(parsedate_to_datetime(when).timestamp()) if when else None
            except Exception:  # noqa: BLE001
                ts = _parse_time(when)
            ts = ts or now_ts()
            if since_ts and ts < since_ts:
                continue
            tags = tags_for(title)
            if group in ("central_bank",) and "macro" not in tags:
                tags.append("macro")
            if group == "regulator" and "regulation" not in tags:
                tags.append("regulation")
            if group == "institution" and "institution" not in tags:
                tags.append("institution")
            out.append({"id": item_id(link, title), "ts": ts, "source": group, "group": group,
                        "kind": "official" if group != "news" else "news",
                        "title": title, "url": link, "domain": org, "org": org, "tags": tags})
        return out, None
    except Exception as e:  # noqa: BLE001
        log("feed", org, "failed:", e)
        return [], str(e)[:120]


# ---- Reddit --------------------------------------------------------------------
# Reddit now returns 403 on the .json endpoints for every non-OAuth client, from
# cloud and home IPs alike. The public .rss feed still serves, but only to a
# browser user-agent. It carries no score, so items rank on recency alone.
REDDIT_UA = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                            "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36")}


def reddit(sub, since_ts):
    try:
        # Reddit 429s when the subreddits are fetched back to back.
        time.sleep(3)
        root = ET.fromstring(http("https://www.reddit.com/r/%s/hot.rss?limit=25" % sub,
                                  headers=REDDIT_UA, retries=1, timeout=25))
        out = []
        for entry in root.iter():
            if entry.tag.split("}")[-1].lower() != "entry":
                continue
            title, link, when = "", None, ""
            for child in entry:
                tag = child.tag.split("}")[-1].lower()
                if tag == "title":
                    title = strip_html(child.text or "")
                elif tag == "link" and child.get("href"):
                    link = child.get("href")
                elif tag in ("updated", "published") and not when:
                    when = child.text or ""
            if not title or not link:
                continue
            try:
                ts = int(datetime.strptime(when[:19], "%Y-%m-%dT%H:%M:%S")
                         .replace(tzinfo=timezone.utc).timestamp())
            except Exception:  # noqa: BLE001
                ts = now_ts()
            if since_ts and ts < since_ts:
                continue
            out.append({"id": item_id(link, title), "ts": ts, "source": "reddit",
                        "group": "social", "kind": "post", "title": title, "url": link,
                        "domain": "r/" + sub, "tags": tags_for(title) or ["crypto"],
                        "score": 0})
        return out, None
    except Exception as e:  # noqa: BLE001
        log("reddit", sub, "failed:", e)
        return [], str(e)[:120]


# ---- Derivatives crowding (Hyperliquid, on-chain perps) ------------------------
def hyperliquid():
    try:
        meta, ctxs = http_json("https://api.hyperliquid.xyz/info", data={"type": "metaAndAssetCtxs"})
        out = {}
        for asset, ctx in zip(meta.get("universe", []), ctxs):
            name = asset.get("name")
            if name in SYMS:
                mark = float(ctx.get("markPx") or 0)
                out[name] = {
                    "funding_h": float(ctx.get("funding") or 0),          # hourly funding rate
                    "oi_usd": float(ctx.get("openInterest") or 0) * mark,  # open interest in USD
                    "premium": float(ctx.get("premium") or 0),
                }
        return out or None
    except Exception as e:  # noqa: BLE001
        log("hyperliquid failed:", e)
        return None
