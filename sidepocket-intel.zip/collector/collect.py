"""Hourly run: refresh prices, gather news/posts/official releases/derivatives,
compute the composite sentiment index and append everything to history."""
import time

from common import SYMS, append_jsonl, iso, load_json, log, now_ts, path, save_json
import sources as src
import series as ser

RECENT_DAYS = 14
RECENT_MAX = 600


def merge_items(new_items):
    f = path("items", "recent.json")
    recent = load_json(f, []) or []
    known = {i["id"] for i in recent}
    fresh = [i for i in new_items if i.get("id") and i["id"] not in known]
    cutoff = now_ts() - RECENT_DAYS * 86400
    merged = [i for i in recent + fresh if i.get("ts", 0) >= cutoff]
    merged.sort(key=lambda i: -i.get("ts", 0))
    save_json(f, merged[:RECENT_MAX])
    # permanent monthly archive of every new item
    by_month = {}
    for i in fresh:
        by_month.setdefault(time.strftime("%Y-%m", time.gmtime(i["ts"])), []).append(i)
    for m, rows in by_month.items():
        append_jsonl(path("items", "archive-%s.jsonl" % m), sorted(rows, key=lambda r: r["ts"]))
    return merged, fresh


def main():
    t0 = now_ts()
    since = t0 - 2 * 86400

    # prices
    ticker = src.kraken_ticker()
    hourly = {}
    for s in SYMS:
        try:
            hourly[s] = ser.update_series(s, ser.HOUR)
            ser.update_series(s, ser.DAY)
        except Exception as e:  # noqa: BLE001
            log("series update failed", s, e)

    # sentiment + crowding
    fng_rows = src.fear_greed(limit=1)
    fng = fng_rows[-1] if fng_rows else None
    if fng:
        hist = load_json(path("sentiment", "fng_daily.json"), []) or []
        if not hist or hist[-1][0] != fng[0]:
            hist.append(list(fng))
            save_json(path("sentiment", "fng_daily.json"), hist)
    derivs = src.hyperliquid()

    # news + posts + official
    items = []
    items += src.gdelt_articles(src.Q_CRYPTO, "3h", 60, "crypto")
    health = {}

    def add(name, rows, err=None):
        items.extend(rows)
        health[name] = {"ok": err is None, "n": len(rows)} if err is None else {"ok": False, "n": 0, "err": err}

    add("News: crypto (GDELT)", src.gdelt_articles(src.Q_CRYPTO, "3h", 60, "crypto"))
    add("News: world & geopolitics (GDELT)", src.gdelt_articles(src.Q_WORLD, "3h", 40, "geo"))
    add("News: governments (GDELT)", src.gdelt_articles(src.Q_GOV, "3h", 40, "regulation", group="government"))
    add("News: institutional money (GDELT)", src.gdelt_articles(src.Q_INST, "3h", 40, "institution", group="institution"))
    tone = src.gdelt_tone(src.Q_CRYPTO, timespan="24h")
    for feed in src.RSS_FEEDS:
        rows, err = src.rss(feed, since_ts=t0 - 7 * 86400)
        add(feed["org"], rows, err)
    add("Donald Trump (Truth Social)", src.truth_posts(since_ts=t0 - 7 * 86400))
    for sub in ("CryptoCurrency", "Bitcoin"):
        rows, err = src.reddit(sub, since)
        add("Reddit r/" + sub, rows, err)
    recent, fresh = merge_items(items)

    # AI briefing (written by the briefing workflow) contributes a news-risk reading
    brief = load_json(path("briefing.json"), {}) or {}
    ai_risk = None
    bt = brief.get("generated_ts") or 0
    if brief.get("news_risk") is not None and t0 - bt < 10 * 3600:
        ai_risk = brief["news_risk"]

    tone_24h = round(sum(v for _, v in tone) / len(tone), 3) if tone else None
    funding = None
    if derivs:
        vals = [d["funding_h"] for d in derivs.values()]
        funding = sum(vals) / len(vals)
    btc_7d = ser.pct_change(hourly.get("BTC"), 7 * 24)
    comp = ser.components(fng[1] if fng else None, btc_7d, tone_24h, funding, ai_risk)
    score = ser.composite(comp)

    snap = {"t": t0, "score": score, "comp": {k: round(v, 1) for k, v in comp.items()},
            "px": {s: ticker[s]["p"] for s in SYMS} if ticker else None,
            "n_new": len(fresh)}
    append_jsonl(path("history", "intel-%s.jsonl" % time.strftime("%Y", time.gmtime(t0))), [snap])

    top = sorted([i for i in recent if i["ts"] >= t0 - 24 * 3600],
                 key=lambda i: (i.get("group") in ("government", "central_bank", "regulator", "institution"),
                                i.get("score", 0), i["ts"]), reverse=True)[:12]
    latest = {
        "generated_at": iso(t0), "generated_ts": t0,
        "prices": ticker,
        "change_7d": {s: ser.pct_change(hourly.get(s), 7 * 24) for s in SYMS},
        "sentiment": {"score": score, "label": ser.label(score) if score is not None else None,
                      "components": comp, "weights": ser.WEIGHTS},
        "fear_greed": {"value": fng[1], "label": fng[2], "ts": fng[0]} if fng else None,
        "news_tone_24h": tone_24h,
        "derivatives": derivs,
        "items_24h": sum(1 for i in recent if i["ts"] >= t0 - 86400),
        "top_items": top,
        "briefing_ts": bt or None,
        "source_health": health,
    }
    save_json(path("latest.json"), latest, pretty=True)

    # The briefing is asked to look at the last 12 hours and to weight official
    # and big-money sources. recent.json holds 14 days for the app's feed, which
    # is far more than the briefing reads and the single largest thing it is
    # sent. Write the slice it actually uses.
    brief_window = [i for i in recent if i["ts"] >= t0 - 36 * 3600]
    brief_window.sort(key=lambda i: (
        i.get("group") in ("government", "central_bank", "regulator", "institution"),
        i.get("score", 0), i["ts"]), reverse=True)
    save_json(path("items", "brief_feed.json"), brief_window[:160])
    log("done: score=%s new_items=%d in %ds" % (score, len(fresh), now_ts() - t0))

    ins = load_json(path("analysis", "insights.json"), {}) or {}
    if t0 - (ins.get("generated_ts") or 0) > 20 * 3600:
        try:
            import analyze
            analyze.main()
        except Exception as e:  # noqa: BLE001
            log("analysis failed:", e)


if __name__ == "__main__":
    main()
