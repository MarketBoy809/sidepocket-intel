"""Read what is actually inside a company's filings.

The desk stored only filing titles and links, so Ledger could see that a 10-Q
existed and not a word of what it said, and Street could see a 13F was filed
without seeing who bought. Both said so repeatedly, and both were right.

A 10-Q runs to a quarter of a megabyte of text, far too much to keep per
company, so this pulls the passages that decide a thesis - going concern,
covenants, liquidity, dilution, subsequent events - and stores those with
enough surrounding sentence to be quotable. Insider forms are summarised
rather than stored one by one.
"""
import json
import os
import re
import time

from common import http, http_json, iso, load_json, log, now_ts, path, save_json

SEC_UA = {"User-Agent": "Sidepocket-Intel marketboy809@gmail.com"}
SUBMISSIONS = "https://data.sec.gov/submissions/CIK%s.json"
ARCHIVE = "https://www.sec.gov/Archives/edgar/data/%d/%s/%s"

PERIODIC = ("10-Q", "10-K", "10-Q/A", "10-K/A")
EVENT = ("8-K", "8-K/A", "6-K")
INSIDER = ("4", "4/A", "144")
INTERESTING = PERIODIC + EVENT + ("S-1", "S-3", "S-3ASR", "424B5", "13D", "13G", "SC 13D")

# what actually decides whether a company survives or dilutes you
TOPICS = [
    # "going concern value" appears in ordinary contract language, so the flag
    # requires the phrasing an actual warning uses
    ("going concern", r"substantial doubt|ability to continue as a going concern"),
    ("covenants", r"covenant|forbearance|event of default|waiver"),
    ("liquidity", r"minimum liquidity|cash and cash equivalents|liquidity and capital"),
    ("debt", r"maturity date|principal amount|credit agreement|term loan|notes due"),
    ("dilution", r"at-the-market|atm program|public offering|warrant|convertible|"
                 r"shares issued and outstanding"),
    ("subsequent", r"subsequent event"),
    ("impairment", r"impairment|restructuring charge|write-?down"),
    ("guidance", r"guidance|outlook for|expects? (?:revenue|full year)"),
]

MAX_EXCERPTS = 14
EXCERPT_CHARS = 420
CACHE_TTL = 3 * 86400


def strip_html(html):
    s = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html)
    s = re.sub(r"(?is)<[^>]+>", " ", s)
    for a, b in (("&nbsp;", " "), ("&#160;", " "), ("&amp;", "&"), ("&#8217;", "'"),
                 ("&#8220;", '"'), ("&#8221;", '"'), ("&#151;", "-"), ("&#8212;", "-"),
                 ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        s = s.replace(a, b)
    return re.sub(r"\s+", " ", s).strip()


def submissions(cik):
    try:
        return http_json(SUBMISSIONS % cik, headers=SEC_UA, timeout=40, retries=1)
    except Exception as e:  # noqa: BLE001
        log("submissions failed for", cik, e)
        return None


def recent(cik, limit=40):
    """[{form, date, url, doc}] newest first."""
    sub = submissions(cik)
    if not sub:
        return []
    r = (sub.get("filings") or {}).get("recent") or {}
    out = []
    for form, date, acc, doc in zip(r.get("form", []), r.get("filingDate", []),
                                    r.get("accessionNumber", []),
                                    r.get("primaryDocument", [])):
        if not doc:
            continue
        out.append({"form": form, "date": date,
                    "url": ARCHIVE % (int(cik), acc.replace("-", ""), doc)})
        if len(out) >= limit:
            break
    return out


def drop_xbrl_header(text):
    """Modern filings open with a block of inline-XBRL metadata - tickers, CIKs,
    dates and us-gaap tags - before any prose. Quoting that back at the desk is
    noise, so skip to where the document actually starts speaking."""
    head = text[:6000]
    item = re.search(r"Item\s+\d+\.\d+", head)
    if item:
        return text[item.start():]
    # otherwise find the first stretch that reads like a sentence
    m = re.search(r"[A-Z][a-z]+(?:\s+[a-z]+){4,}", head)
    return text[m.start():] if m else text


def document_text(url, cap=400_000):
    try:
        raw = http(url, headers=SEC_UA, timeout=45, retries=1)
        return drop_xbrl_header(strip_html(raw.decode("utf-8", "replace")))[:cap]
    except Exception as e:  # noqa: BLE001
        log("could not read", url.rsplit("/", 1)[-1], e)
        return ""


def excerpts(text, topics=TOPICS, per_topic=2):
    """Quotable passages around the phrases that decide a thesis."""
    out, seen = [], set()
    for label, pattern in topics:
        found = 0
        for m in re.finditer(pattern, text, re.I):
            start = max(0, m.start() - 140)
            end = min(len(text), m.end() + EXCERPT_CHARS - 140)
            snippet = text[start:end].strip()
            # start at a sentence boundary where one is close by
            dot = snippet.find(". ")
            if 0 < dot < 90:
                snippet = snippet[dot + 2:]
            key = snippet[:70].lower()
            if key in seen:
                continue
            seen.add(key)
            out.append({"topic": label, "text": snippet})
            found += 1
            if found >= per_topic:
                break
        if len(out) >= MAX_EXCERPTS:
            break
    return out[:MAX_EXCERPTS]


def insider_summary(rows):
    """Insider forms are many and small. Count them rather than storing each:
    a cluster of Form 4s or 144s is the signal, not any single one."""
    fours = [r for r in rows if r["form"].startswith("4")]
    one44 = [r for r in rows if r["form"] == "144"]
    if not fours and not one44:
        return None
    dates = sorted({r["date"] for r in fours + one44}, reverse=True)[:6]
    return {"form4_count": len(fours), "form144_count": len(one44),
            "recent_dates": dates,
            "note": "Form 4 is a completed insider transaction; Form 144 is notice of "
                    "an intended sale. Neither is the company issuing new stock."}


def enrich(ticker, cik=None, force=False):
    """Write data/filings/<TICKER>.json: what the documents actually say."""
    ticker = ticker.upper()
    out_file = path("filings", "%s.json" % ticker)
    old = load_json(out_file)
    if old and not force and now_ts() - old.get("updated_ts", 0) < CACHE_TTL:
        return old

    if not cik:
        snap = load_json(path("equities", "%s.json" % ticker)) or {}
        cik = snap.get("cik")
    if not cik:
        log("no CIK for", ticker)
        return None

    rows = recent(cik)
    if not rows:
        return None

    doc = {"ticker": ticker, "cik": cik, "updated": iso(), "updated_ts": now_ts(),
           "filings": [r for r in rows if r["form"] in INTERESTING][:10],
           "insiders": insider_summary(rows),
           "read": []}

    # the newest periodic report, then the newest couple of events
    targets = []
    periodic = next((r for r in rows if r["form"] in PERIODIC), None)
    if periodic:
        targets.append(periodic)
    targets += [r for r in rows if r["form"] in EVENT][:2]

    for t in targets:
        text = document_text(t["url"])
        if not text:
            continue
        ex = excerpts(text) if t["form"] in PERIODIC else [
            {"topic": "event", "text": text[:1800]}]
        doc["read"].append({"form": t["form"], "date": t["date"], "url": t["url"],
                            "chars": len(text), "excerpts": ex})
        time.sleep(0.6)          # SEC asks for under 10 requests a second

    save_json(out_file, doc, pretty=True)
    log("filings %s: read %d document(s), %d excerpt(s)"
        % (ticker, len(doc["read"]), sum(len(r["excerpts"]) for r in doc["read"])))
    return doc


if __name__ == "__main__":
    import sys
    for t in sys.argv[1:] or ["EOSE"]:
        d = enrich(t, force=True)
        if not d:
            print("%-6s nothing" % t)
            continue
        print("%-6s %d filings listed, %d read" % (t, len(d["filings"]), len(d["read"])))
        for r in d["read"]:
            print("   %-6s %s  %d excerpts" % (r["form"], r["date"], len(r["excerpts"])))
            for e in r["excerpts"][:3]:
                print("      [%s] %s" % (e["topic"], e["text"][:150]))
