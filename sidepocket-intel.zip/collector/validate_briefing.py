"""Checks the AI briefing written by Claude. Keeps the previous one if the new file is broken."""
import json
import os
import subprocess
import sys

from common import iso, now_ts, path, save_json

REQUIRED = ["headline", "summary", "news_risk", "drivers"]


def main():
    f = path("briefing.json")
    try:
        with open(f, encoding="utf-8") as fh:
            b = json.load(fh)
        missing = [k for k in REQUIRED if k not in b]
        if missing:
            raise ValueError("missing keys: %s" % missing)
        b["news_risk"] = max(0, min(100, int(round(float(b["news_risk"])))))
        b["generated_ts"] = now_ts()
        b["generated_at"] = iso(b["generated_ts"])
        b["drivers"] = [d for d in b.get("drivers", []) if isinstance(d, dict)][:8]
        save_json(f, b, pretty=True)
        # keep a history of briefings for the app's timeline
        hist = path("history", "briefings.jsonl")
        os.makedirs(os.path.dirname(hist), exist_ok=True)
        with open(hist, "a", encoding="utf-8") as h:
            h.write(json.dumps({"t": b["generated_ts"], "headline": b["headline"],
                                "news_risk": b["news_risk"], "mood": b.get("mood")},
                               ensure_ascii=False) + "\n")
        print("briefing ok:", b["headline"])
    except Exception as e:  # noqa: BLE001
        print("briefing invalid, restoring previous:", e, file=sys.stderr)
        r = subprocess.run(["git", "checkout", "--", "data/briefing.json"], check=False)
        if r.returncode != 0 and os.path.exists(f):
            os.remove(f)  # no previous version to fall back to


if __name__ == "__main__":
    main()
