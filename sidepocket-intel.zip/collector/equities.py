"""Equity data for the debating bots.

Any ticker a bot names has to be checkable and, later, scoreable - otherwise the
ranking is theatre. This module answers three questions about an arbitrary US
ticker, all keyless:

  does it exist?      -> Yahoo 404s on a bogus symbol, and the SEC maps real ones
  what has it done?   -> daily closes, two years
  why might it move?  -> recent news (GDELT) and filings (SEC EDGAR)

Yahoo's chart endpoint is unofficial and is currently the only keyless source of
daily closes; if it ever goes dark, scoring stalls until it is replaced.
"""
import json
import time
import xml.etree.ElementTree as ET

from common import DATA, http, http_json, item_id, iso, load_json, log, now_ts, path, save_json, strip_html

BROWSER_UA = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                             "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36")}
SEC_UA = {"User-Agent": "Sidepocket-Intel marketboy809@gmail.com"}

CHART = "https://query1.finance.yahoo.com/v8/finance/chart/%s?range=%s&interval=1d"
TICKER_MAP = "https://www.sec.gov/files/company_tickers.json"
EDGAR_ATOM = ("https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=%s"
              "&type=&dateb=&owner=include&count=8&output=atom")
GDELT = "https://api.gdeltproject.org/api/v2/doc/doc"

MAP_FILE = path("equities", "_tickers.json")
MAP_TTL = 7 * 86400
SNAP_TTL = 6 * 3600


# ---- ticker -> company ------------------------------------------------------
def ticker_map(force=False):
    """SEC's official ticker -> CIK/company table, cached for a week."""
    cached = load_json(MAP_FILE)
    if cached and not force and now_ts() - cached.get("ts", 0) < MAP_TTL:
        return cached["by"]
    try:
        raw = http_json(TICKER_MAP, headers=SEC_UA, timeout=40)
        by = {}
        for v in raw.values():
            t = (v.get("ticker") or "").upper()
            if t:
                by[t] = {"cik": "%010d" % int(v["cik_str"]), "name": v.get("title") or t}
        if by:
            save_json(MAP_FILE, {"ts": now_ts(), "by": by})
            log("ticker map: %d symbols" % len(by))
            return by
    except Exception as e:  # noqa: BLE001
        log("ticker map failed:", e)
    return (cached or {}).get("by", {})


def resolve(ticker):
    """Returns {'ticker','name','cik'} or None if the symbol is not a real one."""
    t = (ticker or "").strip().upper().lstrip("$")
    if not t or len(t) > 6 or not t.replace(".", "").replace("-", "").isalnum():
        return None
    hit = ticker_map().get(t)
    if hit:
        return {"ticker": t, "name": hit["name"], "cik": hit["cik"]}
    # Not in the SEC table (ETF, ADR, trust). Let the price feed decide.
    if candles(t, "1mo"):
        return {"ticker": t, "name": t, "cik": None}
    return None


# ---- prices -----------------------------------------------------------------
def candles(ticker, rng="2y"):
    """Daily closes as {'t':[unix...], 'c':[close...]} or None."""
    try:
        d = http_json(CHART % (ticker, rng), headers=BROWSER_UA, timeout=30, retries=1)
        r = (d.get("chart") or {}).get("result") or []
        if not r:
            return None
        r = r[0]
        ts = r.get("timestamp") or []
        closes = ((r.get("indicators") or {}).get("quote") or [{}])[0].get("close") or []
        t, c = [], []
        for i, v in enumerate(closes):
            if v is not None and i < len(ts):
                t.append(int(ts[i]))
                c.append(round(float(v), 4))
        if not c:
            return None
        return {"t": t, "c": c, "currency": (r.get("meta") or {}).get("currency")}
    except Exception:  # noqa: BLE001 - a 404 here means "no such ticker"
        return None


def pct_over(series, days):
    """Percent change over the last N calendar days, or None."""
    if not series or len(series["c"]) < 2:
        return None
    cutoff = series["t"][-1] - days * 86400
    base = None
    for i, ts in enumerate(series["t"]):
        if ts >= cutoff:
            base = series["c"][i]
            break
    if base in (None, 0):
        return None
    return round((series["c"][-1] - base) / base * 100, 2)


# ---- why it might move ------------------------------------------------------
def news(name, ticker, limit=8, timespan="14d"):
    q = '"%s"' % name if name and name != ticker else '"%s" (stock OR shares)' % ticker
    try:
        from urllib.parse import quote
        url = ("%s?query=%s&mode=artlist&maxrecords=%d&format=json&timespan=%s"
               % (GDELT, quote(q), limit, timespan))
        d = http_json(url, headers=BROWSER_UA, timeout=30, retries=1)
        out = []
        for a in (d.get("articles") or [])[:limit]:
            title = strip_html(a.get("title") or "")
            url_a = a.get("url") or ""
            if not title or not url_a:
                continue
            ts = 0
            try:
                ts = int(time.mktime(time.strptime(a.get("seendate", "")[:15], "%Y%m%dT%H%M%S")))
            except Exception:  # noqa: BLE001
                ts = now_ts()
            out.append({"id": item_id(url_a, title), "ts": ts, "title": title,
                        "url": url_a, "domain": a.get("domain") or ""})
        return out
    except Exception as e:  # noqa: BLE001
        log("news failed for", ticker, e)
        return []


def filings(cik, limit=6):
    if not cik:
        return []
    try:
        root = ET.fromstring(http(EDGAR_ATOM % cik, headers=SEC_UA, timeout=30, retries=1))
        out = []
        for entry in root.iter():
            if entry.tag.split("}")[-1].lower() != "entry":
                continue
            title, link, when = "", None, ""
            for child in entry:
                tag = child.tag.split("}")[-1].lower()
                if tag == "title":
                    title = strip_html(child.text or "")
                elif tag == "link" and child.get("href"):
                    link = child.get("href")
                elif tag in ("updated", "filing-date") and not when:
                    when = child.text or ""
            if not title or not link:
                continue
            ts = now_ts()
            try:
                ts = int(time.mktime(time.strptime(when[:10], "%Y-%m-%d")))
            except Exception:  # noqa: BLE001
                pass
            out.append({"ts": ts, "title": title, "url": link})
            if len(out) >= limit:
                break
        return out
    except Exception as e:  # noqa: BLE001
        log("filings failed for CIK", cik, e)
        return []


# ---- the one call the bots' runner uses -------------------------------------
def snapshot(ticker, force=False, with_context=True):
    """Everything known about one ticker, cached on disk. None if not a real symbol."""
    who = resolve(ticker)
    if not who:
        return None
    f = path("equities", "%s.json" % who["ticker"])
    old = load_json(f)
    if old and not force and now_ts() - old.get("updated_ts", 0) < SNAP_TTL:
        return old

    series = candles(who["ticker"], "2y")
    if not series:
        return None
    closes = series["c"]
    hi = max(closes[-252:]) if len(closes) >= 2 else closes[-1]
    lo = min(closes[-252:]) if len(closes) >= 2 else closes[-1]
    snap = {
        "ticker": who["ticker"], "name": who["name"], "cik": who["cik"],
        "updated": iso(), "updated_ts": now_ts(),
        "price": closes[-1], "currency": series.get("currency"),
        "change": {"1w": pct_over(series, 7), "1m": pct_over(series, 30),
                   "3m": pct_over(series, 91), "1y": pct_over(series, 365)},
        "range52": {"hi": round(hi, 4), "lo": round(lo, 4),
                    "from_hi": round((closes[-1] - hi) / hi * 100, 2) if hi else None},
        "series": series,
    }
    if with_context:
        snap["news"] = news(who["name"], who["ticker"])
        snap["filings"] = filings(who["cik"])
    save_json(f, snap)
    return snap


def close_on(ticker, ts):
    """Closing price on or just after a moment - used to settle predictions."""
    snap = load_json(path("equities", "%s.json" % ticker.upper()))
    s = (snap or {}).get("series")
    if not s:
        s = candles(ticker, "2y")
    if not s:
        return None
    for i, t in enumerate(s["t"]):
        if t >= ts:
            return s["c"][i]
    return s["c"][-1] if s["c"] else None


if __name__ == "__main__":  # quick manual check
    import sys
    for arg in sys.argv[1:] or ["NVDA"]:
        s = snapshot(arg, force=True)
        if not s:
            print("%-6s not a real ticker" % arg)
            continue
        print("%-6s %-28s %8.2f  1m %6s%%  1y %7s%%  %d news  %d filings"
              % (s["ticker"], s["name"][:28], s["price"], s["change"]["1m"],
                 s["change"]["1y"], len(s.get("news", [])), len(s.get("filings", []))))
