"""Run one round of the debating desk.

Builds the context, lets Claude write the round, then validates it in code before
anything is kept. The prompt asks the analysts to be truthful; this module does
not rely on that. Every ticker is checked against a real listing, every price
claim against our own snapshot, every reply against a real parent.
"""
import json
import os
import re
import subprocess
import sys
import time

import bot_stats
import equities
import filings
from common import DATA, iso, item_id, load_json, log, now_ts, path, save_json

CLAUDE = os.path.expandvars(r"%USERPROFILE%\.local\bin\claude.exe")
ROOT = os.path.dirname(DATA)
CONTEXT = path("bots", "_context.json")
ROUND = path("bots", "_round.json")
THREADS = path("bots", "threads.jsonl")
PREDICTIONS = path("bots", "predictions.jsonl")
WATCHLIST = path("bots", "watchlist.json")

RECENT_POSTS = 24
MAX_POSTS = 12
PROMPT = ("Read prompts/bots_round.md and follow it exactly. "
          "Write only data/bots/_round.json.")


# ---------------------------------------------------------------- context ----
def market_status(now=None):
    """Is the US market open, and how long until it turns over? A bot writing an
    intraday plan needs to know whether it has a tape to trade against."""
    from datetime import datetime, timedelta, timezone as tz
    now = now or datetime.now(tz.utc)
    # US equities run 09:30-16:00 New York; EDT is UTC-4, EST UTC-5. March to
    # early November is daylight time, which covers the cases that matter here.
    offset = -4 if 3 <= now.month <= 10 else -5
    ny = now + timedelta(hours=offset)
    weekday = ny.weekday() < 5
    open_min, close_min = 9 * 60 + 30, 16 * 60
    mins = ny.hour * 60 + ny.minute
    is_open = weekday and open_min <= mins < close_min

    if is_open:
        return {"open": True, "session": "regular",
                "minutes_to_close": close_min - mins,
                "new_york_time": ny.strftime("%a %H:%M")}
    if weekday and mins < open_min:
        wait = open_min - mins
    else:
        days = 1
        probe = ny + timedelta(days=1)
        while probe.weekday() >= 5:
            probe += timedelta(days=1)
            days += 1
        wait = days * 1440 - mins + open_min
    return {"open": False, "session": "closed",
            "minutes_to_open": wait,
            "new_york_time": ny.strftime("%a %H:%M")}


def build_context():
    roster = load_json(path("bots", "roster.json"), {}) or {}
    posts = bot_stats.read_jsonl(THREADS)[-RECENT_POSTS:]
    preds = bot_stats.read_jsonl(PREDICTIONS)
    watch = load_json(WATCHLIST, {"tickers": []}) or {"tickers": []}

    snaps = {}
    for t in watch.get("tickers", [])[:20]:
        s = load_json(path("equities", "%s.json" % t))
        if not s:
            continue
        entry = {"name": s.get("name"), "price": s.get("price"),
                 "change": s.get("change"), "range52": s.get("range52"),
                 "news": [n["title"] for n in (s.get("news") or [])[:5]]}
        # what the filings actually say, not just that they exist
        fil = load_json(path("filings", "%s.json" % t))
        if fil:
            entry["filings"] = {
                "list": [{"form": f["form"], "date": f["date"]}
                         for f in (fil.get("filings") or [])[:6]],
                "insiders": fil.get("insiders"),
                "read": [{"form": r["form"], "date": r["date"], "url": r["url"],
                          "excerpts": r["excerpts"]} for r in (fil.get("read") or [])],
            }
        else:
            entry["filings"] = {"list": [{"form": f.get("title", "")[:18],
                                          "date": None}
                                         for f in (s.get("filings") or [])[:3]],
                                "read": [], "note": "contents not pulled yet"}
        snaps[t] = entry

    latest = load_json(path("latest.json"), {}) or {}
    news = [{"title": i.get("title"), "org": i.get("source") or i.get("domain"),
             "url": i.get("url")}
            for i in (latest.get("top_items") or [])[:20]]

    ctx = {
        "now": iso(),
        "market": market_status(),
        "roster": roster,
        "recent_thread": [{"id": p["id"], "bot": p["bot"], "kind": p.get("kind"),
                           "text": p.get("text", "")[:400], "tickers": p.get("tickers"),
                           "parent": p.get("parent")} for p in posts],
        "open_predictions": [{"id": p["id"], "bot": p["bot"], "ticker": p["ticker"],
                              "direction": p["direction"], "target_pct": p.get("target_pct"),
                              "horizon_days": p.get("horizon_days"),
                              "confidence": p.get("confidence"),
                              "thesis": p.get("thesis")}
                             for p in preds if p.get("status") == "open"][-30:],
        "scoreboard": load_json(path("bots", "scores.json"), {}) or {},
        "researched_tickers": snaps,
        "market_news": news,
    }
    save_json(CONTEXT, ctx, pretty=True)
    return ctx


# --------------------------------------------------------------- validate ----
NUM = re.compile(r"\$\s?(\d[\d,]*\.?\d*)")


def _price_claims_ok(text, tickers, snaps):
    """Reject a post stating a price that contradicts our own snapshot by >5%."""
    if len(tickers) != 1:
        return True, None                      # can't attribute a number to one name
    snap = snaps.get(tickers[0].upper())
    if not snap or not snap.get("price"):
        return True, None
    real = float(snap["price"])
    for m in NUM.finditer(text or ""):
        try:
            claimed = float(m.group(1).replace(",", ""))
        except ValueError:
            continue
        if claimed <= 0:
            continue
        # only judge numbers in the same order of magnitude as the price
        if 0.2 * real <= claimed <= 5 * real and abs(claimed - real) / real > 0.05:
            return False, "claims $%.2f, snapshot says $%.2f" % (claimed, real)
    return True, None


CHART_KINDS = ("price", "compare", "drawdown")
CHART_RANGES = ("1m", "3m", "6m", "1y", "2y")


def _clean_chart(c):
    """A chart is a request to draw our own data, never a carrier for the bot's
    numbers. Anything whose ticker we have not researched is dropped."""
    if not isinstance(c, dict):
        return None
    kind = str(c.get("kind") or "").lower()
    if kind not in CHART_KINDS:
        return None
    rng = str(c.get("range") or "6m").lower()
    if rng not in CHART_RANGES:
        rng = "6m"
    names = c.get("tickers") if kind == "compare" else [c.get("ticker")]
    out = []
    for t in (names or [])[:4]:
        who = equities.resolve(t) if t else None
        if who and load_json(path("equities", "%s.json" % who["ticker"])):
            out.append(who["ticker"])
    if not out:
        return None
    if kind == "compare" and len(out) < 2:
        return None
    return ({"kind": kind, "tickers": out, "range": rng} if kind == "compare"
            else {"kind": kind, "ticker": out[0], "range": rng})


# ---- quotation control ------------------------------------------------------
# A quote that does not say what the bot claims contaminates the thread, and
# every later round reads that thread back as context. So quoting is not
# policed by asking nicely: any long quoted span in a post must be found,
# word for word, in something the desk can actually show.
MIN_POLICED_QUOTE = 40          # shorter spans are idiom, not evidence
QUOTE_SPAN = re.compile(r"[\"“”‘’']{1}([^\"“”\n]{20,600})"
                        r"[\"“”‘’']{1}")


def _norm(s):
    """Compare on words alone: whitespace, case and smart punctuation vary
    between a filing's HTML and anything retyped from it."""
    s = (s or "").replace("’", "'").replace("‘", "'")
    s = s.replace("“", '"').replace("”", '"').replace("—", "-")
    return re.sub(r"[^a-z0-9 ]+", " ", re.sub(r"\s+", " ", s.lower())).strip()


def build_quote_corpus(ctx, tickers=None):
    """Everything a bot is allowed to quote, keyed by excerpt id, plus a pool of
    free text (news headlines, colleagues' own posts) that needs no citation."""
    by_id, pool = {}, []
    for t, snap in (ctx.get("researched_tickers") or {}).items():
        if tickers and t not in tickers:
            continue
        fil = snap.get("filings") or {}
        for doc in fil.get("read") or []:
            for ex in doc.get("excerpts") or []:
                if ex.get("id"):
                    by_id[ex["id"]] = ex
                pool.append(_norm(ex.get("text")))
        for n in snap.get("news") or []:
            pool.append(_norm(n if isinstance(n, str) else n.get("title")))
    for p in ctx.get("recent_thread") or []:
        pool.append(_norm(p.get("text")))
    for n in ctx.get("market_news") or []:
        pool.append(_norm(n.get("title")))
    return by_id, pool


def check_quotes(post, by_id, pool):
    """(ok, reason). Rejects a post whose quoted material cannot be shown."""
    text = post.get("text") or ""
    declared = post.get("quotes") or []

    # 1. every declared citation must resolve, and match the passage it names
    clean = []
    for q in declared[:6]:
        if not isinstance(q, dict):
            continue
        qid, qtext = q.get("id"), _norm(q.get("text"))
        if not qid or qid not in by_id:
            return False, "cites %s, which is not a real excerpt" % (qid or "nothing")
        if qtext and qtext not in _norm(by_id[qid]["text"]):
            return False, "quote does not appear in %s" % qid
        src = by_id[qid]
        clean.append({"id": qid, "text": q.get("text", "")[:400],
                      "form": src.get("form"), "date": src.get("date"),
                      "topic": src.get("topic")})

    # 2. any long quoted span in the prose must be findable somewhere real
    allowed = pool + [_norm(by_id[q["id"]]["text"]) for q in clean]
    for m in QUOTE_SPAN.finditer(text):
        span = _norm(m.group(1))
        if len(span) < MIN_POLICED_QUOTE:
            continue
        if not any(span in hay for hay in allowed if hay):
            return False, 'quotes "%s..." which is in no source on file' % m.group(1)[:60]

    post["quotes"] = clean
    return True, None


# how long a setup of each kind may stand before it is withdrawn
CLASS_MAX_DAYS = {"intraday": 2, "swing": 14, "position": 60, "trend": 190}


def _num(v):
    try:
        f = float(v)
        return f if f > 0 else None
    except (TypeError, ValueError):
        return None


def _clean_call(pr, bot, post_id, snaps):
    """A call is only kept if it is a plan someone could follow: a real entry
    band, a stop on the losing side of it, and a target on the winning side.
    Returns (call, reason_rejected)."""
    who = equities.resolve(pr.get("ticker"))
    if not who:
        return None, "call on an unknown ticker %s" % pr.get("ticker")
    snap = snaps.get(who["ticker"]) or load_json(path("equities", "%s.json" % who["ticker"]))
    if not snap or not snap.get("price"):
        return None, "call on unpriced ticker %s" % who["ticker"]

    up = str(pr.get("direction", "up")).lower() != "down"
    zone = pr.get("entry_zone") or []
    lo = _num(zone[0]) if len(zone) > 0 else None
    hi = _num(zone[1]) if len(zone) > 1 else None
    if lo is None or hi is None:
        return None, "call on %s has no entry zone" % who["ticker"]
    if lo > hi:
        lo, hi = hi, lo
    stop = _num(pr.get("stop"))
    target = _num(pr.get("target"))
    if stop is None or target is None:
        return None, "call on %s is missing a stop or target" % who["ticker"]

    mid = (lo + hi) / 2.0
    # the stop has to be able to lose and the target has to be able to win
    if up and not (stop < lo and target > hi):
        return None, "long on %s: stop %.2f / target %.2f do not straddle the zone" % (
            who["ticker"], stop, target)
    if not up and not (stop > hi and target < lo):
        return None, "short on %s: stop %.2f / target %.2f do not straddle the zone" % (
            who["ticker"], stop, target)

    cls = str(pr.get("horizon_class", "swing")).lower()
    if cls not in CLASS_MAX_DAYS:
        cls = "swing"
    valid = int(_num(pr.get("valid_days")) or 10)
    valid = max(1, min(valid, CLASS_MAX_DAYS[cls]))

    risk = abs(mid - stop)
    reward = abs(target - mid)
    if risk <= 0:
        return None, "call on %s has no risk between entry and stop" % who["ticker"]

    try:
        conf = float(pr.get("confidence", 0.5))
    except (TypeError, ValueError):
        conf = 0.5

    return {
        "id": item_id("call-%s-%s-%d" % (bot, who["ticker"], now_ts())),
        "ts": now_ts(), "bot": bot, "post_id": post_id,
        "ticker": who["ticker"], "direction": "up" if up else "down",
        "horizon_class": cls,
        "entry_zone": [round(lo, 4), round(hi, 4)],
        "stop": round(stop, 4), "target": round(target, 4),
        "valid_days": valid,
        "rr": round(reward / risk, 2),
        "price_at_call": float(snap["price"]),
        "confidence": min(0.95, max(0.05, conf)),
        "thesis": (pr.get("thesis") or "")[:300],
        "invalidation": (pr.get("invalidation") or "")[:300],
        "status": "open",          # open -> armed -> hit/miss, or expired
    }, None


def validate(raw, ctx):
    """Returns (kept_posts, predictions, rejected)."""
    known_ids = {p["id"] for p in ctx["recent_thread"]}
    roster_ids = {r["id"] for r in ctx["roster"].get("researchers", [])}
    roster_ids |= {ctx["roster"].get("auditor", {}).get("id"),
                   ctx["roster"].get("chair", {}).get("id")}
    snaps = {}
    for t in set(sum([p.get("tickers") or [] for p in raw.get("posts", [])], [])):
        s = load_json(path("equities", "%s.json" % t.upper()))
        if s:
            snaps[t.upper()] = s

    by_id, pool = build_quote_corpus(ctx)
    kept, preds, rejected = [], [], []
    index_map = {}
    for n, p in enumerate(raw.get("posts", [])[:MAX_POSTS], start=1):
        bot = (p.get("bot") or "").strip().lower()
        text = (p.get("text") or "").strip()
        if bot not in roster_ids:
            rejected.append((bot or "?", "not on the roster"))
            continue
        if len(text) < 20:
            rejected.append((bot, "empty or trivial post"))
            continue

        # tickers must be real listings
        tickers, bad = [], None
        for t in (p.get("tickers") or [])[:4]:
            who = equities.resolve(t)
            if who:
                tickers.append(who["ticker"])
            else:
                bad = t
                break
        if bad:
            rejected.append((bot, "invented ticker %s" % bad))
            continue

        ok, why = _price_claims_ok(text, tickers, snaps)
        if not ok:
            rejected.append((bot, why))
            continue

        ok, why = check_quotes(p, by_id, pool)
        if not ok:
            rejected.append((bot, why))
            continue

        # resolve the parent reference
        parent = p.get("parent")
        if isinstance(parent, str) and parent.startswith("#"):
            parent = index_map.get(parent[1:])
        if parent and parent not in known_ids and parent not in index_map.values():
            parent = None

        pid = item_id("%s-%s-%d" % (bot, text[:40], now_ts() + n))
        index_map[str(n)] = pid
        post = {"id": pid, "ts": now_ts() + n, "bot": bot,
                "kind": p.get("kind") or ("reply" if parent else "post"),
                "parent": parent, "text": text, "tickers": tickers,
                "summary": (p.get("summary") or "").strip()[:120],
                "quotes": p.get("quotes") or [],
                "links": [l for l in (p.get("links") or []) if l.get("url")][:3]}
        chart = _clean_chart(p.get("chart"))
        if chart:
            post["chart"] = chart
        if post["kind"] == "verdict" and bot == "auditor":
            post["against"] = [a for a in (p.get("against") or []) if a in roster_ids]
        kept.append(post)

        pr = p.get("prediction") or p.get("call")
        if isinstance(pr, dict) and pr.get("ticker") and tickers:
            call, why = _clean_call(pr, bot, pid, snaps)
            if call:
                preds.append(call)
            elif why:
                rejected.append((bot, why))
    return kept, preds, rejected


# ------------------------------------------------------------------- run -----
def append_jsonl(p, rows):
    if not rows:
        return
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def run_claude(timeout=1500):
    if not os.path.exists(CLAUDE):
        log("Claude Code CLI not found at", CLAUDE)
        return False
    if os.path.exists(ROUND):
        os.remove(ROUND)
    cmd = [CLAUDE, "-p", PROMPT,
           "--allowedTools", "Read,Write,Glob,Grep,WebSearch,WebFetch",
           "--max-turns", "40"]
    log("asking Claude for a round...")
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                       timeout=timeout, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        log("claude exited", p.returncode, (p.stderr or "")[-400:])
    return os.path.exists(ROUND)


CHAIR_EVERY = 3
CHAIR_FILE = path("bots", "chair.json")
CHAIR_PROMPT = ("Read prompts/chair.md and follow it exactly. "
                "Write only data/bots/chair.json.")


def _maybe_chair():
    """The Chair speaks every third round. More often and it repeats itself;
    less often and a passenger rides free for too long."""
    state = load_json(path("bots", "chair_state.json"), {"rounds": 0}) or {"rounds": 0}
    state["rounds"] = state.get("rounds", 0) + 1
    save_json(path("bots", "chair_state.json"), state)
    if state["rounds"] % CHAIR_EVERY:
        log("chair speaks in %d round(s)" % (CHAIR_EVERY - state["rounds"] % CHAIR_EVERY))
        return False
    if not os.path.exists(CLAUDE):
        return False
    log("the Chair is reviewing the desk...")
    try:
        p = subprocess.run([CLAUDE, "-p", CHAIR_PROMPT,
                            "--allowedTools", "Read,Write,Glob,Grep",
                            "--max-turns", "20"],
                           cwd=ROOT, capture_output=True, text=True, timeout=900,
                           encoding="utf-8", errors="replace")
        if p.returncode != 0:
            log("chair exited", p.returncode)
    except Exception as e:  # noqa: BLE001
        log("chair failed:", e)
        return False
    note = load_json(CHAIR_FILE)
    if not note or not note.get("text"):
        log("chair wrote nothing usable")
        return False
    note["ts"] = now_ts()
    note["round"] = state["rounds"]
    save_json(CHAIR_FILE, note, pretty=True)
    log("chair: %s" % (note.get("headline") or "")[:100])
    return True


def main():
    ctx = build_context()
    if not run_claude():
        log("no round produced")
        return 1
    raw = load_json(ROUND, {}) or {}
    kept, preds, rejected = validate(raw, ctx)

    for bot, why in rejected:
        log("rejected %s: %s" % (bot, why))
    if not kept:
        log("nothing survived validation")
        return 1

    append_jsonl(THREADS, kept)
    append_jsonl(PREDICTIONS, preds)

    # research anything newly named so the next round can talk numbers
    watch = load_json(WATCHLIST, {"tickers": []}) or {"tickers": []}
    named = set(watch.get("tickers", []))
    for t in (raw.get("new_tickers") or [])[:6]:
        who = equities.resolve(t)
        if who:
            named.add(who["ticker"])
    for p in kept:
        named.update(p["tickers"])
    for t in sorted(named):
        if not load_json(path("equities", "%s.json" % t)):
            log("researching", t)
            equities.snapshot(t)
            time.sleep(2)
    # read the documents for whatever the desk is actually arguing about, so the
    # next round can quote a covenant instead of saying it cannot read one
    discussed = sorted({t for p in kept for t in p["tickers"]})[:6]
    for t in discussed:
        try:
            filings.enrich(t)
        except Exception as e:  # noqa: BLE001
            log("filings failed for", t, e)

    # documents the desk asked for by name; stored so the next round can cite them
    for u, ok, why in filings.take_nominations(raw.get("sources")):
        log("source %s: %s" % ("stored" if ok else "refused", why or u))
    save_json(WATCHLIST, {"tickers": sorted(named), "updated": iso()}, pretty=True)

    bot_stats.compute()
    _maybe_chair()
    log("round: %d posts, %d predictions, %d rejected" % (len(kept), len(preds), len(rejected)))
    for p in kept:
        log("  %-9s %s" % (p["bot"], p["text"][:90].replace("\n", " ")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
