"""Run one round of the debating desk.

Builds the context, lets Claude write the round, then validates it in code before
anything is kept. The prompt asks the analysts to be truthful; this module does
not rely on that. Every ticker is checked against a real listing, every price
claim against our own snapshot, every reply against a real parent.
"""
import json
import os
import re
import subprocess
import sys
import time

import bot_stats
import equities
from common import DATA, iso, item_id, load_json, log, now_ts, path, save_json

CLAUDE = os.path.expandvars(r"%USERPROFILE%\.local\bin\claude.exe")
ROOT = os.path.dirname(DATA)
CONTEXT = path("bots", "_context.json")
ROUND = path("bots", "_round.json")
THREADS = path("bots", "threads.jsonl")
PREDICTIONS = path("bots", "predictions.jsonl")
WATCHLIST = path("bots", "watchlist.json")

RECENT_POSTS = 24
MAX_POSTS = 12
PROMPT = ("Read prompts/bots_round.md and follow it exactly. "
          "Write only data/bots/_round.json.")


# ---------------------------------------------------------------- context ----
def build_context():
    roster = load_json(path("bots", "roster.json"), {}) or {}
    posts = bot_stats.read_jsonl(THREADS)[-RECENT_POSTS:]
    preds = bot_stats.read_jsonl(PREDICTIONS)
    watch = load_json(WATCHLIST, {"tickers": []}) or {"tickers": []}

    snaps = {}
    for t in watch.get("tickers", [])[:20]:
        s = load_json(path("equities", "%s.json" % t))
        if s:
            snaps[t] = {"name": s.get("name"), "price": s.get("price"),
                        "change": s.get("change"), "range52": s.get("range52"),
                        "news": [n["title"] for n in (s.get("news") or [])[:5]],
                        "filings": [f["title"] for f in (s.get("filings") or [])[:3]]}

    latest = load_json(path("latest.json"), {}) or {}
    news = [{"title": i.get("title"), "org": i.get("source") or i.get("domain"),
             "url": i.get("url")}
            for i in (latest.get("top_items") or [])[:20]]

    ctx = {
        "now": iso(),
        "roster": roster,
        "recent_thread": [{"id": p["id"], "bot": p["bot"], "kind": p.get("kind"),
                           "text": p.get("text", "")[:400], "tickers": p.get("tickers"),
                           "parent": p.get("parent")} for p in posts],
        "open_predictions": [{"id": p["id"], "bot": p["bot"], "ticker": p["ticker"],
                              "direction": p["direction"], "target_pct": p.get("target_pct"),
                              "horizon_days": p.get("horizon_days"),
                              "confidence": p.get("confidence"),
                              "thesis": p.get("thesis")}
                             for p in preds if p.get("status") == "open"][-30:],
        "scoreboard": load_json(path("bots", "scores.json"), {}) or {},
        "researched_tickers": snaps,
        "market_news": news,
    }
    save_json(CONTEXT, ctx, pretty=True)
    return ctx


# --------------------------------------------------------------- validate ----
NUM = re.compile(r"\$\s?(\d[\d,]*\.?\d*)")


def _price_claims_ok(text, tickers, snaps):
    """Reject a post stating a price that contradicts our own snapshot by >5%."""
    if len(tickers) != 1:
        return True, None                      # can't attribute a number to one name
    snap = snaps.get(tickers[0].upper())
    if not snap or not snap.get("price"):
        return True, None
    real = float(snap["price"])
    for m in NUM.finditer(text or ""):
        try:
            claimed = float(m.group(1).replace(",", ""))
        except ValueError:
            continue
        if claimed <= 0:
            continue
        # only judge numbers in the same order of magnitude as the price
        if 0.2 * real <= claimed <= 5 * real and abs(claimed - real) / real > 0.05:
            return False, "claims $%.2f, snapshot says $%.2f" % (claimed, real)
    return True, None


CHART_KINDS = ("price", "compare", "drawdown")
CHART_RANGES = ("1m", "3m", "6m", "1y", "2y")


def _clean_chart(c):
    """A chart is a request to draw our own data, never a carrier for the bot's
    numbers. Anything whose ticker we have not researched is dropped."""
    if not isinstance(c, dict):
        return None
    kind = str(c.get("kind") or "").lower()
    if kind not in CHART_KINDS:
        return None
    rng = str(c.get("range") or "6m").lower()
    if rng not in CHART_RANGES:
        rng = "6m"
    names = c.get("tickers") if kind == "compare" else [c.get("ticker")]
    out = []
    for t in (names or [])[:4]:
        who = equities.resolve(t) if t else None
        if who and load_json(path("equities", "%s.json" % who["ticker"])):
            out.append(who["ticker"])
    if not out:
        return None
    if kind == "compare" and len(out) < 2:
        return None
    return ({"kind": kind, "tickers": out, "range": rng} if kind == "compare"
            else {"kind": kind, "ticker": out[0], "range": rng})


def validate(raw, ctx):
    """Returns (kept_posts, predictions, rejected)."""
    known_ids = {p["id"] for p in ctx["recent_thread"]}
    roster_ids = {r["id"] for r in ctx["roster"].get("researchers", [])}
    roster_ids |= {ctx["roster"].get("auditor", {}).get("id"),
                   ctx["roster"].get("chair", {}).get("id")}
    snaps = {}
    for t in set(sum([p.get("tickers") or [] for p in raw.get("posts", [])], [])):
        s = load_json(path("equities", "%s.json" % t.upper()))
        if s:
            snaps[t.upper()] = s

    kept, preds, rejected = [], [], []
    index_map = {}
    for n, p in enumerate(raw.get("posts", [])[:MAX_POSTS], start=1):
        bot = (p.get("bot") or "").strip().lower()
        text = (p.get("text") or "").strip()
        if bot not in roster_ids:
            rejected.append((bot or "?", "not on the roster"))
            continue
        if len(text) < 20:
            rejected.append((bot, "empty or trivial post"))
            continue

        # tickers must be real listings
        tickers, bad = [], None
        for t in (p.get("tickers") or [])[:4]:
            who = equities.resolve(t)
            if who:
                tickers.append(who["ticker"])
            else:
                bad = t
                break
        if bad:
            rejected.append((bot, "invented ticker %s" % bad))
            continue

        ok, why = _price_claims_ok(text, tickers, snaps)
        if not ok:
            rejected.append((bot, why))
            continue

        # resolve the parent reference
        parent = p.get("parent")
        if isinstance(parent, str) and parent.startswith("#"):
            parent = index_map.get(parent[1:])
        if parent and parent not in known_ids and parent not in index_map.values():
            parent = None

        pid = item_id("%s-%s-%d" % (bot, text[:40], now_ts() + n))
        index_map[str(n)] = pid
        post = {"id": pid, "ts": now_ts() + n, "bot": bot,
                "kind": p.get("kind") or ("reply" if parent else "post"),
                "parent": parent, "text": text, "tickers": tickers,
                "summary": (p.get("summary") or "").strip()[:120],
                "links": [l for l in (p.get("links") or []) if l.get("url")][:3]}
        chart = _clean_chart(p.get("chart"))
        if chart:
            post["chart"] = chart
        if post["kind"] == "verdict" and bot == "auditor":
            post["against"] = [a for a in (p.get("against") or []) if a in roster_ids]
        kept.append(post)

        pr = p.get("prediction")
        if isinstance(pr, dict) and pr.get("ticker") and tickers:
            who = equities.resolve(pr["ticker"])
            snap = snaps.get((who or {}).get("ticker", ""))
            if who and snap and snap.get("price"):
                try:
                    conf = float(pr.get("confidence", 0.5))
                except (TypeError, ValueError):
                    conf = 0.5
                preds.append({
                    "id": item_id("pred-%s-%s-%d" % (bot, who["ticker"], now_ts() + n)),
                    "ts": now_ts(), "bot": bot, "post_id": pid,
                    "ticker": who["ticker"],
                    "direction": "down" if str(pr.get("direction")).lower() == "down" else "up",
                    "target_pct": abs(float(pr.get("target_pct") or 5)),
                    "horizon_days": max(1, int(pr.get("horizon_days") or 30)),
                    "confidence": min(0.95, max(0.05, conf)),
                    "thesis": (pr.get("thesis") or "")[:300],
                    "invalidation": (pr.get("invalidation") or "")[:300],
                    "entry_price": float(snap["price"]),
                    "status": "open",
                })
            else:
                rejected.append((bot, "prediction on unpriced ticker %s" % pr.get("ticker")))
    return kept, preds, rejected


# ------------------------------------------------------------------- run -----
def append_jsonl(p, rows):
    if not rows:
        return
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def run_claude(timeout=1500):
    if not os.path.exists(CLAUDE):
        log("Claude Code CLI not found at", CLAUDE)
        return False
    if os.path.exists(ROUND):
        os.remove(ROUND)
    cmd = [CLAUDE, "-p", PROMPT,
           "--allowedTools", "Read,Write,Glob,Grep,WebSearch,WebFetch",
           "--max-turns", "40"]
    log("asking Claude for a round...")
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                       timeout=timeout, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        log("claude exited", p.returncode, (p.stderr or "")[-400:])
    return os.path.exists(ROUND)


def main():
    ctx = build_context()
    if not run_claude():
        log("no round produced")
        return 1
    raw = load_json(ROUND, {}) or {}
    kept, preds, rejected = validate(raw, ctx)

    for bot, why in rejected:
        log("rejected %s: %s" % (bot, why))
    if not kept:
        log("nothing survived validation")
        return 1

    append_jsonl(THREADS, kept)
    append_jsonl(PREDICTIONS, preds)

    # research anything newly named so the next round can talk numbers
    watch = load_json(WATCHLIST, {"tickers": []}) or {"tickers": []}
    named = set(watch.get("tickers", []))
    for t in (raw.get("new_tickers") or [])[:6]:
        who = equities.resolve(t)
        if who:
            named.add(who["ticker"])
    for p in kept:
        named.update(p["tickers"])
    for t in sorted(named):
        if not load_json(path("equities", "%s.json" % t)):
            log("researching", t)
            equities.snapshot(t)
            time.sleep(2)
    save_json(WATCHLIST, {"tickers": sorted(named), "updated": iso()}, pretty=True)

    bot_stats.compute()
    log("round: %d posts, %d predictions, %d rejected" % (len(kept), len(preds), len(rejected)))
    for p in kept:
        log("  %-9s %s" % (p["bot"], p["text"][:90].replace("\n", " ")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
