"""What each analyst has learned, anchored to things that actually happened.

A bot writing its own lessons learns nothing: it will produce a flattering
paragraph about staying disciplined and carry on exactly as before. So a lesson
is only accepted when it cites an **anchor** - a call that settled, a ruling the
Auditor made against it, or a position it withdrew - and the anchor is checked
to exist and to belong to that bot before the lesson is kept.

The record half needs no model at all. Hit rate by horizon class, whether its
stated confidence ran hot or cold, which of its setups never fired: all of that
is arithmetic over its own history, and it is what the bot is shown first.

Lessons are written by one Claude call covering every analyst with new evidence,
and only when there is new evidence. Most rounds settle nothing and cost nothing
here.
"""
import json
import os
import subprocess

import bot_stats
from common import DATA, iso, load_json, log, now_ts, path, save_json

CLAUDE = os.path.expandvars(r"%USERPROFILE%\.local\bin\claude.exe")
ROOT = os.path.dirname(DATA)
MEM_DIR = path("memory")
PENDING = path("memory", "_pending.json")
OUT = path("memory", "_lessons.json")
PROMPT = ("Read prompts/lessons.md and follow it exactly. The evidence is in "
          "data/memory/_pending.json. Write only data/memory/_lessons.json.")

MAX_LESSONS = 12          # per bot, oldest dropped
ROLE_BOTS = {"auditor", "chair"}


def mem_file(bot):
    return path("memory", "%s.json" % bot)


def load_mem(bot):
    return load_json(mem_file(bot), {"bot": bot, "lessons": [], "seen": []}) or {
        "bot": bot, "lessons": [], "seen": []}


# ---------------------------------------------------------------- record ----
def computed_record(bot, scores, preds):
    """Arithmetic over this bot's own history. No model involved."""
    v = (scores.get("bots") or {}).get(bot) or {}
    mine = [p for p in preds if p.get("bot") == bot]
    settled = [p for p in mine if p.get("status") in ("hit", "miss")]

    rec = {
        "calls": len(mine),
        "settled": len(settled),
        "hit_rate": v.get("hit_rate"),
        "avg_r": v.get("avg_r"),
        "by_class": v.get("by_class") or {},
        "never_fired": v.get("never_fired"),
        "withdrawn": v.get("withdrawn"),
        "conceded": v.get("conceded"),
        "violations": v.get("violations"),
    }

    # did its stated confidence run hot or cold
    if settled:
        conf = [p.get("confidence") for p in settled
                if isinstance(p.get("confidence"), (int, float))]
        if conf:
            said = sum(conf) / len(conf)
            got = sum(1 for p in settled if p["status"] == "hit") / len(settled)
            gap = got - said
            rec["confidence_said"] = round(said, 2)
            rec["confidence_got"] = round(got, 2)
            rec["calibration"] = (
                "about right" if abs(gap) < 0.12 else
                ("too cautious - it was right more often than it claimed"
                 if gap > 0 else
                 "too confident - it claimed more than it delivered"))

    rec["outcomes"] = [{
        "id": p.get("id"), "ticker": p.get("ticker"), "direction": p.get("direction"),
        "class": p.get("horizon_class"), "status": p.get("status"),
        "r": p.get("r_multiple"), "outcome": (p.get("outcome") or "")[:120],
        "thesis": (p.get("thesis") or "")[:160],
    } for p in settled[-8:]]
    return rec


# --------------------------------------------------------------- anchors ----
def pending_anchors(bot, preds, posts, seen):
    """New evidence this bot has not yet drawn a lesson from."""
    out = []
    for p in preds:
        if p.get("bot") != bot or p.get("id") in seen:
            continue
        if p.get("status") in ("hit", "miss", "withdrawn", "expired"):
            out.append({
                "type": "call", "id": p["id"],
                "what": "%s %s %s: %s" % (p.get("ticker"), p.get("direction"),
                                          p.get("status"), (p.get("outcome") or "")[:110]),
                "thesis": (p.get("thesis") or "")[:200],
                "r": p.get("r_multiple"), "confidence": p.get("confidence"),
            })
    for p in posts:
        if p.get("id") in seen:
            continue
        if p.get("kind") == "verdict" and bot in (p.get("against") or []):
            out.append({"type": "ruling", "id": p["id"],
                        "what": "the Auditor ruled against it: " + (p.get("text") or "")[:220]})
        elif p.get("kind") == "concede" and p.get("bot") == bot:
            out.append({"type": "concession", "id": p["id"],
                        "what": (p.get("summary") or p.get("text") or "")[:220]})
    return out[:6]


# --------------------------------------------------------------- lessons ----
def gather(scores=None, preds=None, posts=None):
    """Build the evidence packet. Returns the number of bots with new evidence."""
    scores = scores or load_json(path("bots", "scores.json"), {}) or {}
    preds = preds if preds is not None else bot_stats.read_jsonl(
        path("bots", "predictions.jsonl"))
    posts = posts if posts is not None else bot_stats.read_jsonl(
        path("bots", "threads.jsonl"))

    packet = {}
    for bot in (scores.get("bots") or {}):
        if bot in ROLE_BOTS:
            continue
        mem = load_mem(bot)
        anchors = pending_anchors(bot, preds, posts, set(mem.get("seen") or []))
        if not anchors:
            continue
        packet[bot] = {
            "record": computed_record(bot, scores, preds),
            "existing_lessons": [l["text"] for l in (mem.get("lessons") or [])[-6:]],
            "new_evidence": anchors,
        }
    if packet:
        save_json(PENDING, {"generated": iso(), "bots": packet}, pretty=True)
    return len(packet)


def _valid_anchor(bot, anchor_id, preds, posts):
    for p in preds:
        if p.get("id") == anchor_id and p.get("bot") == bot:
            return True
    for p in posts:
        if p.get("id") != anchor_id:
            continue
        if p.get("bot") == bot:                       # its own concession
            return True
        if p.get("kind") == "verdict" and bot in (p.get("against") or []):
            return True
    return False


def absorb(preds=None, posts=None):
    """Keep only lessons whose anchor is real and belongs to that bot."""
    raw = load_json(OUT, {}) or {}
    preds = preds if preds is not None else bot_stats.read_jsonl(
        path("bots", "predictions.jsonl"))
    posts = posts if posts is not None else bot_stats.read_jsonl(
        path("bots", "threads.jsonl"))
    kept = 0
    for bot, rows in (raw.get("lessons") or {}).items():
        if bot in ROLE_BOTS or not isinstance(rows, list):
            continue
        mem = load_mem(bot)
        seen = set(mem.get("seen") or [])
        for r in rows[:4]:
            if not isinstance(r, dict):
                continue
            text = (r.get("text") or "").strip()
            anchor = r.get("anchor")
            if len(text) < 25 or not anchor:
                continue
            if not _valid_anchor(bot, anchor, preds, posts):
                log("lesson dropped for %s: anchor %s is not its own" % (bot, anchor))
                continue
            mem["lessons"].append({"ts": now_ts(), "text": text[:400],
                                   "anchor": anchor, "kind": r.get("kind", "")[:24]})
            seen.add(anchor)
            kept += 1
        # anchors it was shown but drew nothing from should not be offered again
        for a in (raw.get("considered") or {}).get(bot, []):
            seen.add(a)
        mem["lessons"] = mem["lessons"][-MAX_LESSONS:]
        mem["seen"] = sorted(seen)[-400:]
        mem["updated"] = iso()
        save_json(mem_file(bot), mem, pretty=True)
    if os.path.exists(OUT):
        os.remove(OUT)
    return kept


def reflect(timeout=900):
    """One call, covering every analyst with new evidence. Skipped when there is none."""
    n = gather()
    if not n:
        log("nothing new to learn from")
        return 0
    if not os.path.exists(CLAUDE):
        return 0
    if os.path.exists(OUT):
        os.remove(OUT)
    log("%d analyst(s) have new evidence to learn from" % n)
    try:
        p = subprocess.run([CLAUDE, "-p", PROMPT,
                            "--allowedTools", "Read,Write,Glob,Grep",
                            "--max-turns", "16"],
                           cwd=ROOT, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        if p.returncode != 0:
            log("lessons run exited", p.returncode)
    except Exception as e:  # noqa: BLE001
        log("lessons run failed:", e)
        return 0
    kept = absorb()
    log("kept %d lesson(s)" % kept)
    if os.path.exists(PENDING):
        os.remove(PENDING)
    return kept


def for_context(bot, scores, preds):
    """What a bot is shown about itself each round."""
    mem = load_mem(bot)
    return {
        "record": computed_record(bot, scores, preds),
        "lessons": [{"text": l["text"], "from": l.get("anchor")}
                    for l in (mem.get("lessons") or [])[-5:]],
    }


if __name__ == "__main__":
    import sys
    sys.exit(0 if reflect() >= 0 else 1)
