"""Objective scoreboard for the debating desk.

The Chair is only allowed to reason from numbers computed here, never from its
own impression of a bot. The point of this module is to make "she scores badly
but she makes the desk better" a measurable claim:

  hit_rate     did the call happen
  brier        was the stated confidence honest
  assists      did this bot's post lead to someone else's correct call
  provoked     do others actually reply to it
  conceded     does it change its mind when shown evidence
  first_on     did it name a stock before the desk noticed it
  violations   did the Auditor catch it inventing or moving goalposts

A bot with a poor hit_rate but high assists is carrying the desk. A bot with a
good hit_rate and no assists is a passenger. Both facts come out of here.
"""
import json
import os
from collections import defaultdict

from common import iso, load_json, log, now_ts, path, save_json

# these two hold roles, not research seats: they are never ranked as researchers
ROLE_BOTS = {"auditor", "chair"}

THREADS = path("bots", "threads.jsonl")
PREDICTIONS = path("bots", "predictions.jsonl")
SCORES = path("bots", "scores.json")


def read_jsonl(p):
    out = []
    if not os.path.exists(p):
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:  # noqa: BLE001
                continue
    return out


def _ancestors(post, by_id, limit=6):
    """Walk up a reply chain, newest parent first."""
    out, seen, cur = [], set(), post.get("parent")
    while cur and cur not in seen and len(out) < limit:
        seen.add(cur)
        p = by_id.get(cur)
        if not p:
            break
        out.append(p)
        cur = p.get("parent")
    return out


# What one notional position is worth, so "earned" is a number in money rather
# than an abstract R. Nothing is actually traded; this is what following every
# call with the same stake would have done.
STAKE = 1000.0


def pnl_of(c):
    """(pnl_in_dollars, is_realized) for one call, or (None, False) if it has
    not been entered yet. A call that never armed never had money on it."""
    up = c.get("direction") != "down"
    status = c.get("status")

    if status in ("hit", "miss"):
        entry = c.get("entry_price")
        exit_ = c.get("exit_price")
        if entry and exit_:
            move = (exit_ - entry) / entry
            return STAKE * (move if up else -move), True
        # legacy calls resolve without an exit price; use how far it actually got
        if c.get("actual_pct") is not None and status == "hit":
            return STAKE * abs(c["actual_pct"]) / 100.0, True
        if c.get("actual_pct") is not None:
            return STAKE * (c["actual_pct"] / 100.0 if up else -c["actual_pct"] / 100.0), True
        return None, False

    if status == "expired":
        return 0.0, True          # never entered, so it neither won nor lost

    if status == "withdrawn":
        # Closing a position is not the same as never having held one. Whatever
        # it was worth when the bot walked away is banked, win or lose -
        # otherwise a bot could escape a losing call by retracting it.
        entry = c.get("entry_price") or c.get("price_at_call")
        exit_ = c.get("exit_price") or c.get("last_price")
        if entry and exit_:
            move = (exit_ - entry) / entry
            return STAKE * (move if up else -move), True
        return 0.0, True

    # live: mark to the last price we have
    entry = c.get("entry_price")
    last = c.get("last_price")
    if status == "armed" and entry and last:
        move = (last - entry) / entry
        return STAKE * (move if up else -move), False
    # legacy calls are treated as entered when made
    if c.get("target_pct") and entry and last:
        move = (last - entry) / entry
        return STAKE * (move if up else -move), False
    return None, False



def _provokers(pred, by_id):
    """Who argued this call into existence.

    Credit goes to the nearest ancestor of the call's post written by someone
    else: the analyst whose argument the caller was answering. Awarded when the
    call is made, not when it resolves - tying it to resolution meant assists
    read zero for every bot in every round until something settled, which made
    the carrier/passenger distinction unusable exactly when it was most needed."""
    src = by_id.get(pred.get("post_id") or "")
    if not src:
        return []
    mine = pred.get("bot")
    for anc in _ancestors(src, by_id):
        if anc.get("bot") and anc["bot"] != mine:
            return [anc["bot"]]
    return []



# ---- the shape of an analyst -------------------------------------------------
# Eight axes, each 0-100, each computed from something the bot actually did.
# Nothing here is a judgement or a hand-set rating: if a number cannot be earned
# yet it stays at the neutral 50 and `confidence` says how much of the shape is
# real. A trait you cannot trace to an event is a trait worth deleting.
TRAIT_ORDER = ["accuracy", "edge", "calibration", "influence",
               "provocation", "candour", "discipline", "originality"]


def _clamp(v, lo=0.0, hi=100.0):
    return max(lo, min(hi, v))


def traits_for(v):
    """v is one bot's computed row. Returns {trait: 0-100} plus a confidence."""
    resolved = v.get("resolved") or 0
    posts = v.get("posts") or 0

    # did the call happen. Needs a sample; drifts from neutral as one arrives.
    if resolved:
        weight = min(1.0, resolved / 8.0)
        accuracy = 50 + (v["hit_rate"] * 100 - 50) * weight
    else:
        accuracy = 50.0

    # what the trade paid per unit of risk taken. +2R is a strong desk result.
    if v.get("avg_r") is not None:
        edge = 50 + v["avg_r"] * 25
    elif v.get("planned_rr") is not None:
        edge = 45 + min(v["planned_rr"], 3) * 5      # intent only, so capped low
    else:
        edge = 50.0

    # was the stated confidence honest. Brier 0 is perfect, 0.25 is a coin flip.
    calibration = 50.0 if v.get("brier") is None else 100 - v["brier"] * 200

    # did this bot's arguments produce other people's calls
    influence = 50 + (v.get("assists") or 0) * 12 + (v.get("assists_landed") or 0) * 8

    # does the room engage with it at all
    provocation = _clamp((v.get("provoked") or 0) * 55 + 20)

    # changing your mind in public against being caught overstating
    conc, viol = v.get("conceded") or 0, v.get("violations") or 0
    candour = 50.0 if not (conc or viol) else 100.0 * conc / (conc + viol)

    # plans that are real plans: a sane reward-to-risk, and setups that fire
    discipline = 50.0
    if v.get("planned_rr") is not None:
        discipline = 35 + min(v["planned_rr"], 4) * 15
    if v.get("never_fired") is not None:
        discipline -= v["never_fired"] * 30          # setups that never trigger

    # first to a name the desk later piled into
    originality = 45 + (v.get("first_on") or 0) * 18

    out = {
        "accuracy": accuracy, "edge": edge, "calibration": calibration,
        "influence": influence, "provocation": provocation, "candour": candour,
        "discipline": discipline, "originality": originality,
    }
    out = {k: round(_clamp(x), 1) for k, x in out.items()}
    # how much of this shape is earned rather than defaulted
    out["confidence"] = round(_clamp(
        (min(resolved, 8) / 8.0) * 55 + (min(posts, 12) / 12.0) * 45), 0)
    return out


def compute(posts=None, preds=None):
    posts = read_jsonl(THREADS) if posts is None else posts
    preds = read_jsonl(PREDICTIONS) if preds is None else preds
    by_id = {p["id"]: p for p in posts if p.get("id")}

    bots = defaultdict(lambda: {
        "posts": 0, "replies_made": 0, "replies_received": 0,
        "predictions": 0, "open": 0, "armed": 0, "expired": 0,
        "resolved": 0, "hits": 0, "misses": 0,
        "brier_sum": 0.0, "brier_n": 0, "r_sum": 0.0, "r_n": 0, "rr_sum": 0.0, "rr_n": 0,
        "assists": 0, "assists_landed": 0, "withdrawn": 0,
        "conceded": 0, "violations": 0, "first_on": 0,
        "open_pnl": 0.0, "realized_pnl": 0.0, "live_bets": 0,
        "by_class": defaultdict(lambda: {"resolved": 0, "hits": 0, "r_sum": 0.0}),
    })

    # ---- posting behaviour ----
    for p in posts:
        b = p.get("bot")
        if not b:
            continue
        s = bots[b]
        s["posts"] += 1
        if p.get("kind") == "concede":
            s["conceded"] += 1
        parent = by_id.get(p.get("parent") or "")
        if parent:
            s["replies_made"] += 1
            if parent.get("bot") and parent["bot"] != b:
                bots[parent["bot"]]["replies_received"] += 1
        if p.get("kind") == "verdict":
            for target in p.get("against") or []:
                bots[target]["violations"] += 1

    # ---- who named a ticker first ----
    first_seen = {}
    for p in sorted(posts, key=lambda x: x.get("ts", 0)):
        for t in p.get("tickers") or []:
            first_seen.setdefault(t.upper(), (p.get("bot"), p.get("ts", 0)))
    followers = defaultdict(set)
    for p in posts:
        for t in p.get("tickers") or []:
            followers[t.upper()].add(p.get("bot"))
    for t, (bot, _ts) in first_seen.items():
        if bot and len(followers[t]) >= 3:
            bots[bot]["first_on"] += 1

    # ---- predictions and assists ----
    for pr in preds:
        b = pr.get("bot")
        if not b:
            continue
        s = bots[b]
        s["predictions"] += 1
        for who in _provokers(pr, by_id):
            bots[who]["assists"] += 1
        status = pr.get("status")
        cls = pr.get("horizon_class") or "swing"
        if isinstance(pr.get("rr"), (int, float)):
            s["rr_sum"] += pr["rr"]
            s["rr_n"] += 1
        if status == "withdrawn":
            # closed by the bot itself; the money is real, the thesis is not judged
            s["withdrawn"] += 1
        elif status == "expired":
            # never armed: not wrong, but it cost the desk a slot
            s["expired"] += 1
        elif status == "armed":
            s["armed"] += 1
        pnl, realized = pnl_of(pr)
        if pnl is not None:
            if realized:
                s["realized_pnl"] += pnl
            else:
                s["open_pnl"] += pnl
                s["live_bets"] += 1
        if status in ("hit", "miss"):
            s["resolved"] += 1
            correct = 1.0 if status == "hit" else 0.0
            s["hits" if status == "hit" else "misses"] += 1
            s["by_class"][cls]["resolved"] += 1
            s["by_class"][cls]["hits"] += int(correct)
            if isinstance(pr.get("r_multiple"), (int, float)):
                s["r_sum"] += pr["r_multiple"]
                s["r_n"] += 1
                s["by_class"][cls]["r_sum"] += pr["r_multiple"]
            conf = pr.get("confidence")
            if isinstance(conf, (int, float)) and 0 <= conf <= 1:
                s["brier_sum"] += (conf - correct) ** 2
                s["brier_n"] += 1
            # a landed assist: the provoked call actually worked
            if correct:
                for who in _provokers(pr, by_id):
                    bots[who]["assists_landed"] += 1
        elif status == "open":
            s["open"] += 1

    # ---- derive the readable numbers ----
    out = {}
    for b, s in bots.items():
        resolved = s["resolved"]
        out[b] = {
            "posts": s["posts"],
            "replies_made": s["replies_made"],
            "replies_received": s["replies_received"],
            "provoked": round(s["replies_received"] / s["posts"], 2) if s["posts"] else 0,
            "predictions": s["predictions"],
            "open": s["open"],
            "armed": s["armed"],
            "expired": s["expired"],
            "resolved": resolved,
            "hits": s["hits"],
            "misses": s["misses"],
            "hit_rate": round(s["hits"] / resolved, 3) if resolved else None,
            "brier": round(s["brier_sum"] / s["brier_n"], 3) if s["brier_n"] else None,
            # what the trade actually paid, in units of the risk it took
            "avg_r": round(s["r_sum"] / s["r_n"], 2) if s["r_n"] else None,
            "total_r": round(s["r_sum"], 2) if s["r_n"] else None,
            "planned_rr": round(s["rr_sum"] / s["rr_n"], 2) if s["rr_n"] else None,
            "never_fired": round(s["expired"] / s["predictions"], 2) if s["predictions"] else None,
            # what following every one of this bot's calls with the same stake
            # would have made. Nothing is actually traded.
            "open_pnl": round(s["open_pnl"], 2),
            "realized_pnl": round(s["realized_pnl"], 2),
            "total_pnl": round(s["open_pnl"] + s["realized_pnl"], 2),
            "live_bets": s["live_bets"],
            "stake": STAKE,
            "by_class": {k: {"resolved": v["resolved"],
                             "hit_rate": round(v["hits"] / v["resolved"], 3) if v["resolved"] else None,
                             "avg_r": round(v["r_sum"] / v["resolved"], 2) if v["resolved"] else None}
                         for k, v in s["by_class"].items()},
            "assists": s["assists"],
            "assists_landed": s["assists_landed"],
            "withdrawn": s["withdrawn"],
            "conceded": s["conceded"],
            "violations": s["violations"],
            "first_on": s["first_on"],
            "sample_warning": resolved < 10,
        }

    for _b, _row in out.items():
        _row["traits"] = traits_for(_row)

    group = _group(preds, posts, out)
    scores = {"generated_at": iso(), "generated_ts": now_ts(), "bots": out, "group": group}
    save_json(SCORES, scores, pretty=True)
    return scores


def _group(preds, posts, per_bot):
    resolved = [p for p in preds if p.get("status") in ("hit", "miss")]
    resolved.sort(key=lambda p: p.get("resolved_ts") or 0)
    hits = sum(1 for p in resolved if p["status"] == "hit")

    def rate(rows):
        r = [p for p in rows if p.get("status") in ("hit", "miss")]
        return round(sum(1 for p in r if p["status"] == "hit") / len(r), 3) if r else None

    half = len(resolved) // 2
    # is the desk getting better, or just louder?
    trend = None
    if half >= 5:
        early, late = rate(resolved[:half]), rate(resolved[half:])
        if early is not None and late is not None:
            trend = round(late - early, 3)

    # how often does a ticker get argued rather than agreed with
    by_ticker = defaultdict(set)
    for p in preds:
        if p.get("ticker"):
            by_ticker[p["ticker"].upper()].add(p.get("direction"))
    contested = sum(1 for v in by_ticker.values() if len(v) > 1)

    rs = [p["r_multiple"] for p in resolved if isinstance(p.get("r_multiple"), (int, float))]
    by_class = defaultdict(lambda: {"resolved": 0, "hits": 0})
    for p in resolved:
        c = by_class[p.get("horizon_class") or "swing"]
        c["resolved"] += 1
        c["hits"] += int(p["status"] == "hit")

    return {
        "resolved": len(resolved),
        "hit_rate": round(hits / len(resolved), 3) if resolved else None,
        "hit_rate_trend": trend,
        "avg_r": round(sum(rs) / len(rs), 2) if rs else None,
        "total_r": round(sum(rs), 2) if rs else None,
        "by_class": {k: {"resolved": v["resolved"],
                         "hit_rate": round(v["hits"] / v["resolved"], 3) if v["resolved"] else None}
                     for k, v in by_class.items()},
        "open_calls": sum(1 for p in preds if p.get("status") == "open"),
        "armed": sum(1 for p in preds if p.get("status") == "armed"),
        "expired": sum(1 for p in preds if p.get("status") == "expired"),
        "withdrawn": sum(1 for p in preds if p.get("status") == "withdrawn"),
        "tickers_covered": len(by_ticker),
        "contested_tickers": contested,
        "agreement_index": round(1 - contested / len(by_ticker), 2) if by_ticker else None,
        "posts": len(posts),
        "silent_bots": sorted(b for b, s in per_bot.items()
                              if b not in ROLE_BOTS and s["posts"] == 0),
        # The Auditor rules and the Chair reviews; neither makes calls or courts
        # replies, so researcher metrics say nothing about whether they are
        # doing their job. Judging them by these numbers is simply wrong.
        "passengers": sorted(b for b, s in per_bot.items()
                             if b not in ROLE_BOTS and s["posts"] >= 5
                             and s["assists"] == 0 and s["provoked"] < 0.3),
        "carriers": sorted(b for b, s in per_bot.items()
                           if b not in ROLE_BOTS and s["assists"] >= 3
                           and (s["hit_rate"] is None or s["hit_rate"] < 0.5)),
        "open_pnl": round(sum(s["open_pnl"] for s in per_bot.values()), 2),
        "realized_pnl": round(sum(s["realized_pnl"] for s in per_bot.values()), 2),
        "total_pnl": round(sum(s["total_pnl"] for s in per_bot.values()), 2),
        "stake": STAKE,
    }


if __name__ == "__main__":
    s = compute()
    g = s["group"]
    print("desk: %s resolved, hit rate %s, trend %s, agreement %s"
          % (g["resolved"], g["hit_rate"], g["hit_rate_trend"], g["agreement_index"]))
    for b, v in sorted(s["bots"].items(), key=lambda kv: -(kv[1]["assists"])):
        print("  %-10s posts %3d  hit %-5s  assists %2d  provoked %.2f  concede %d  flags %d"
              % (b, v["posts"], v["hit_rate"], v["assists"], v["provoked"],
                 v["conceded"], v["violations"]))
