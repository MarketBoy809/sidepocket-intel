"""Objective scoreboard for the debating desk.

The Chair is only allowed to reason from numbers computed here, never from its
own impression of a bot. The point of this module is to make "she scores badly
but she makes the desk better" a measurable claim:

  hit_rate     did the call happen
  brier        was the stated confidence honest
  assists      did this bot's post lead to someone else's correct call
  provoked     do others actually reply to it
  conceded     does it change its mind when shown evidence
  first_on     did it name a stock before the desk noticed it
  violations   did the Auditor catch it inventing or moving goalposts

A bot with a poor hit_rate but high assists is carrying the desk. A bot with a
good hit_rate and no assists is a passenger. Both facts come out of here.
"""
import json
import os
from collections import defaultdict

from common import iso, load_json, log, now_ts, path, save_json

THREADS = path("bots", "threads.jsonl")
PREDICTIONS = path("bots", "predictions.jsonl")
SCORES = path("bots", "scores.json")


def read_jsonl(p):
    out = []
    if not os.path.exists(p):
        return out
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:  # noqa: BLE001
                continue
    return out


def _ancestors(post, by_id, limit=6):
    """Walk up a reply chain, newest parent first."""
    out, seen, cur = [], set(), post.get("parent")
    while cur and cur not in seen and len(out) < limit:
        seen.add(cur)
        p = by_id.get(cur)
        if not p:
            break
        out.append(p)
        cur = p.get("parent")
    return out


def compute(posts=None, preds=None):
    posts = read_jsonl(THREADS) if posts is None else posts
    preds = read_jsonl(PREDICTIONS) if preds is None else preds
    by_id = {p["id"]: p for p in posts if p.get("id")}

    bots = defaultdict(lambda: {
        "posts": 0, "replies_made": 0, "replies_received": 0,
        "predictions": 0, "open": 0, "armed": 0, "expired": 0,
        "resolved": 0, "hits": 0, "misses": 0,
        "brier_sum": 0.0, "brier_n": 0, "r_sum": 0.0, "r_n": 0, "rr_sum": 0.0, "rr_n": 0,
        "assists": 0, "conceded": 0, "violations": 0, "first_on": 0,
        "by_class": defaultdict(lambda: {"resolved": 0, "hits": 0, "r_sum": 0.0}),
    })

    # ---- posting behaviour ----
    for p in posts:
        b = p.get("bot")
        if not b:
            continue
        s = bots[b]
        s["posts"] += 1
        if p.get("kind") == "concede":
            s["conceded"] += 1
        parent = by_id.get(p.get("parent") or "")
        if parent:
            s["replies_made"] += 1
            if parent.get("bot") and parent["bot"] != b:
                bots[parent["bot"]]["replies_received"] += 1
        if p.get("kind") == "verdict":
            for target in p.get("against") or []:
                bots[target]["violations"] += 1

    # ---- who named a ticker first ----
    first_seen = {}
    for p in sorted(posts, key=lambda x: x.get("ts", 0)):
        for t in p.get("tickers") or []:
            first_seen.setdefault(t.upper(), (p.get("bot"), p.get("ts", 0)))
    followers = defaultdict(set)
    for p in posts:
        for t in p.get("tickers") or []:
            followers[t.upper()].add(p.get("bot"))
    for t, (bot, _ts) in first_seen.items():
        if bot and len(followers[t]) >= 3:
            bots[bot]["first_on"] += 1

    # ---- predictions and assists ----
    for pr in preds:
        b = pr.get("bot")
        if not b:
            continue
        s = bots[b]
        s["predictions"] += 1
        status = pr.get("status")
        cls = pr.get("horizon_class") or "swing"
        if isinstance(pr.get("rr"), (int, float)):
            s["rr_sum"] += pr["rr"]
            s["rr_n"] += 1
        if status == "expired":
            # never armed: not wrong, but it cost the desk a slot
            s["expired"] += 1
        elif status == "armed":
            s["armed"] += 1
        if status in ("hit", "miss"):
            s["resolved"] += 1
            correct = 1.0 if status == "hit" else 0.0
            s["hits" if status == "hit" else "misses"] += 1
            s["by_class"][cls]["resolved"] += 1
            s["by_class"][cls]["hits"] += int(correct)
            if isinstance(pr.get("r_multiple"), (int, float)):
                s["r_sum"] += pr["r_multiple"]
                s["r_n"] += 1
                s["by_class"][cls]["r_sum"] += pr["r_multiple"]
            conf = pr.get("confidence")
            if isinstance(conf, (int, float)) and 0 <= conf <= 1:
                s["brier_sum"] += (conf - correct) ** 2
                s["brier_n"] += 1
            # an assist goes to whoever this call was arguing with, when it lands
            if correct:
                src = by_id.get(pr.get("post_id") or "")
                if src:
                    for anc in _ancestors(src, by_id):
                        if anc.get("bot") and anc["bot"] != b:
                            bots[anc["bot"]]["assists"] += 1
                            break
        elif status == "open":
            s["open"] += 1

    # ---- derive the readable numbers ----
    out = {}
    for b, s in bots.items():
        resolved = s["resolved"]
        out[b] = {
            "posts": s["posts"],
            "replies_made": s["replies_made"],
            "replies_received": s["replies_received"],
            "provoked": round(s["replies_received"] / s["posts"], 2) if s["posts"] else 0,
            "predictions": s["predictions"],
            "open": s["open"],
            "armed": s["armed"],
            "expired": s["expired"],
            "resolved": resolved,
            "hits": s["hits"],
            "misses": s["misses"],
            "hit_rate": round(s["hits"] / resolved, 3) if resolved else None,
            "brier": round(s["brier_sum"] / s["brier_n"], 3) if s["brier_n"] else None,
            # what the trade actually paid, in units of the risk it took
            "avg_r": round(s["r_sum"] / s["r_n"], 2) if s["r_n"] else None,
            "total_r": round(s["r_sum"], 2) if s["r_n"] else None,
            "planned_rr": round(s["rr_sum"] / s["rr_n"], 2) if s["rr_n"] else None,
            "never_fired": round(s["expired"] / s["predictions"], 2) if s["predictions"] else None,
            "by_class": {k: {"resolved": v["resolved"],
                             "hit_rate": round(v["hits"] / v["resolved"], 3) if v["resolved"] else None,
                             "avg_r": round(v["r_sum"] / v["resolved"], 2) if v["resolved"] else None}
                         for k, v in s["by_class"].items()},
            "assists": s["assists"],
            "conceded": s["conceded"],
            "violations": s["violations"],
            "first_on": s["first_on"],
            "sample_warning": resolved < 10,
        }

    group = _group(preds, posts, out)
    scores = {"generated_at": iso(), "generated_ts": now_ts(), "bots": out, "group": group}
    save_json(SCORES, scores, pretty=True)
    return scores


def _group(preds, posts, per_bot):
    resolved = [p for p in preds if p.get("status") in ("hit", "miss")]
    resolved.sort(key=lambda p: p.get("resolved_ts") or 0)
    hits = sum(1 for p in resolved if p["status"] == "hit")

    def rate(rows):
        r = [p for p in rows if p.get("status") in ("hit", "miss")]
        return round(sum(1 for p in r if p["status"] == "hit") / len(r), 3) if r else None

    half = len(resolved) // 2
    # is the desk getting better, or just louder?
    trend = None
    if half >= 5:
        early, late = rate(resolved[:half]), rate(resolved[half:])
        if early is not None and late is not None:
            trend = round(late - early, 3)

    # how often does a ticker get argued rather than agreed with
    by_ticker = defaultdict(set)
    for p in preds:
        if p.get("ticker"):
            by_ticker[p["ticker"].upper()].add(p.get("direction"))
    contested = sum(1 for v in by_ticker.values() if len(v) > 1)

    rs = [p["r_multiple"] for p in resolved if isinstance(p.get("r_multiple"), (int, float))]
    by_class = defaultdict(lambda: {"resolved": 0, "hits": 0})
    for p in resolved:
        c = by_class[p.get("horizon_class") or "swing"]
        c["resolved"] += 1
        c["hits"] += int(p["status"] == "hit")

    return {
        "resolved": len(resolved),
        "hit_rate": round(hits / len(resolved), 3) if resolved else None,
        "hit_rate_trend": trend,
        "avg_r": round(sum(rs) / len(rs), 2) if rs else None,
        "total_r": round(sum(rs), 2) if rs else None,
        "by_class": {k: {"resolved": v["resolved"],
                         "hit_rate": round(v["hits"] / v["resolved"], 3) if v["resolved"] else None}
                     for k, v in by_class.items()},
        "open_calls": sum(1 for p in preds if p.get("status") == "open"),
        "armed": sum(1 for p in preds if p.get("status") == "armed"),
        "expired": sum(1 for p in preds if p.get("status") == "expired"),
        "tickers_covered": len(by_ticker),
        "contested_tickers": contested,
        "agreement_index": round(1 - contested / len(by_ticker), 2) if by_ticker else None,
        "posts": len(posts),
        "silent_bots": sorted(b for b, s in per_bot.items() if s["posts"] == 0),
        "passengers": sorted(b for b, s in per_bot.items()
                             if s["posts"] >= 5 and s["assists"] == 0 and s["provoked"] < 0.3),
        "carriers": sorted(b for b, s in per_bot.items()
                           if s["assists"] >= 3 and (s["hit_rate"] is None or s["hit_rate"] < 0.5)),
    }


if __name__ == "__main__":
    s = compute()
    g = s["group"]
    print("desk: %s resolved, hit rate %s, trend %s, agreement %s"
          % (g["resolved"], g["hit_rate"], g["hit_rate_trend"], g["agreement_index"]))
    for b, v in sorted(s["bots"].items(), key=lambda kv: -(kv[1]["assists"])):
        print("  %-10s posts %3d  hit %-5s  assists %2d  provoked %.2f  concede %d  flags %d"
              % (b, v["posts"], v["hit_rate"], v["assists"], v["provoked"],
                 v["conceded"], v["violations"]))
