"""Shared helpers: HTTP with retries, JSON files, tagging, time. Standard library only."""
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA = os.path.join(ROOT, "data")
UA = "Sidepocket-Intel/1.0 (personal market research; github actions)"

SYMS = ["BTC", "ETH", "SOL"]


def log(*a):
    print("[intel]", *a, file=sys.stderr, flush=True)


def now_ts():
    return int(time.time())


def iso(ts=None):
    return datetime.fromtimestamp(ts if ts is not None else time.time(), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def http(url, data=None, headers=None, timeout=25, retries=2, pause=2.0):
    """GET (or POST when data is given). Returns bytes, or raises after retries."""
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        body = json.dumps(data).encode() if not isinstance(data, (bytes, bytearray)) else data
        h.setdefault("Content-Type", "application/json")
    last = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, data=body, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001 - network is best effort
            last = e
            if attempt < retries:
                time.sleep(pause * (attempt + 1))
    raise last


def http_json(url, **kw):
    return json.loads(http(url, **kw).decode("utf-8", "replace"))


def path(*parts):
    return os.path.join(DATA, *parts)


def load_json(p, default=None):
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa: BLE001
        return default


def save_json(p, obj, pretty=False):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        if pretty:
            json.dump(obj, f, ensure_ascii=False, indent=1)
        else:
            json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, p)


def append_jsonl(p, rows):
    if not rows:
        return
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n")


def item_id(url, title=""):
    return hashlib.sha1((url or title).encode("utf-8", "replace")).hexdigest()[:16]


def strip_html(s):
    s = re.sub(r"<br\s*/?>|</p>", " ", s or "", flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = (s.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
          .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " "))
    return re.sub(r"\s+", " ", s).strip()


# ---- topic tagging -------------------------------------------------------
_K = {
    "crypto": r"bitcoin|\bbtc\b|crypto|ethereum|\beth\b|solana|stablecoin|blockchain|digital asset|coinbase|binance|\betf\b|defi|tether|usdc",
    "macro": r"federal reserve|\bthe fed\b|\bfed\b|powell|interest rate|rate cut|rate hike|inflation|\bcpi\b|jobs report|payroll|recession|treasury|bond yield|\byields?\b|dollar|\bgdp\b",
    "geo": r"tariff|sanction|\bwar\b|iran|russia|ukraine|israel|gaza|missile|airstrike|\bstrike[sd]?\b|nato|taiwan|trade deal|trade war|middle east|north korea|ceasefire",
    "institution": r"blackrock|fidelity|vanguard|jpmorgan|goldman|morgan stanley|citadel|microstrategy|saylor|strategy inc|sovereign wealth|pension fund|etf (?:inflow|outflow)|\bibit\b|treasury compan",
    "regulation": r"\bsec\b|regulat|congress|senate|\bhouse\b|\bbill\b|\bact\b|cftc|\blaw\b|\bban\b|lawsuit|executive order|clarity act|genius act|strategic reserve",
}
_A = {
    "BTC": r"bitcoin|\bbtc\b",
    "ETH": r"ethereum|\bether\b|\beth\b",
    "SOL": r"solana|\bsol\b",
}
_KC = {k: re.compile(v, re.I) for k, v in _K.items()}
_AC = {k: re.compile(v, re.I) for k, v in _A.items()}


def tags_for(text):
    t = text or ""
    tags = [k for k, rx in _KC.items() if rx.search(t)]
    tags += [k for k, rx in _AC.items() if rx.search(t)]
    return tags


def is_relevant(text):
    return any(rx.search(text or "") for rx in _KC.values())
