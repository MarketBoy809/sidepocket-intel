"""History analyzer. Runs daily. Answers, from stored history:
  1. Market events: every sharp dip/pump per coin, and whether it bounced (the owner's strategy).
  2. Reactions: what prices did after posts/releases from each source and on each topic.
  3. Precursors: which sources/topics appeared *before* dips more often than chance (lift vs base rate),
     checked for stability across the older and newer half of the data.
  4. Analogs: past days whose sentiment/market state looked like today, and what followed.
  5. Dip bounce odds by market regime (fear/greed, above/below the 200-day average).
Output: data/analysis/*.json and data/analysis/insights.json (plain-language findings)."""
import glob
import json
import math
import os
import statistics as st

from common import SYMS, iso, load_json, log, now_ts, path, save_json

H = 3600
DIP = {1: 0.025, 2: 0.035, 4: 0.05}     # fall >= x within w hours = dip event
BOUNCE = 0.015                            # the owner's typical take-profit: +1.5%
PRE_WINDOW = 6 * H                        # "called it" window before an event
MIN_N = 8                                 # minimum items before a source/topic is scored


# ---- data loading ---------------------------------------------------------------
def load_hourly(sym):
    s = load_json(path("prices", "%s_1h.json" % sym))
    if not s or not s.get("c"):
        return None
    return s["t0"], s["c"]


def load_items():
    seen, out = set(), []
    files = sorted(glob.glob(path("items", "archive-*.jsonl")))
    for f in files:
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                try:
                    it = json.loads(line)
                except Exception:  # noqa: BLE001
                    continue
                if it.get("id") in seen:
                    continue
                seen.add(it.get("id"))
                out.append(it)
    for it in load_json(path("items", "truth_relevant.json"), []) or []:
        if it.get("id") not in seen:
            seen.add(it.get("id"))
            out.append(it)
    out.sort(key=lambda i: i.get("ts", 0))
    return out


import re
KEYWORDS = {
    "tariff": r"tariff", "china": r"china|chinese|beijing", "sanctions": r"sanction",
    "war/strike": r"\bwar\b|missile|airstrike|\bstrikes?\b|invasion|attack", "ceasefire": r"ceasefire|peace deal",
    "rate cut": r"rate cut|cut rates|lower rates|cuts? interest", "rate hike": r"rate hike|raise rates|hikes? interest",
    "inflation/CPI": r"inflation|\bcpi\b", "jobs": r"jobs report|payroll|unemployment",
    "ETF": r"\betfs?\b", "strategic reserve": r"strategic (?:bitcoin )?reserve", "stablecoin": r"stablecoin",
    "hack/exploit": r"hack|exploit|breach|drained", "lawsuit/charges": r"lawsuit|sues|sued|charged|indict",
    "ban": r"\bban\b|banned|prohibit", "approval": r"approv", "bill/law": r"\bbill\b|\bact\b|legislation|\blaw\b",
    "liquidation": r"liquidat", "whale": r"whale", "bankruptcy": r"bankrupt|insolven|collapse",
}
KW_RX = {k: re.compile(v, re.I) for k, v in KEYWORDS.items()}


def keywords_of(it):
    t = it.get("title", "")
    return [k for k, rx in KW_RX.items() if rx.search(t)]


def source_key(it):
    return it.get("org") or it.get("domain") or it.get("source") or "unknown"


# ---- helpers ---------------------------------------------------------------------
def idx_at(t0, n, ts):
    """Index of the first hourly close at or after ts."""
    i = int(math.ceil((ts - t0) / H))
    return i if 0 <= i < n else None


def ret(c, i, k):
    if i is None or i + k >= len(c) or c[i] == 0:
        return None
    return (c[i + k] - c[i]) / c[i]


def wilson_low(k, n, z=1.64):
    if n == 0:
        return 0.0
    p = k / n
    d = 1 + z * z / n
    return max(0.0, (p + z * z / (2 * n) - z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / d)


def pct(x, nd=1):
    return None if x is None else round(100 * x, nd)


# ---- 1. events -------------------------------------------------------------------
def find_events(t0, c, sign=-1):
    """Sharp moves. sign=-1 dips, +1 pumps. Merges moves within 12h, keeps the strongest."""
    raw = []
    for i in range(4, len(c)):
        best = None
        for w, thr in DIP.items():
            if c[i - w] == 0:
                continue
            r = (c[i] - c[i - w]) / c[i - w]
            if sign * r >= thr and (best is None or sign * r > sign * best[1]):
                best = (w, r)
        if best:
            raw.append((i, best[0], best[1]))
    merged = []
    for e in raw:
        if merged and e[0] - merged[-1][0] <= 12:
            if sign * e[2] > sign * merged[-1][2]:
                merged[-1] = e
        else:
            merged.append(e)
    events = []
    for i, w, r in merged:
        # bottom (or top) within the next 12h, then check the bounce from that point
        seg = c[i:i + 13]
        j = i + (seg.index(min(seg)) if sign < 0 else seg.index(max(seg)))
        after24 = c[j + 1:j + 25]
        after72 = c[j + 1:j + 73]
        if sign < 0:
            b24 = (max(after24) - c[j]) / c[j] if after24 else None
            b72 = (max(after72) - c[j]) / c[j] if after72 else None
            hrs = next((k + 1 for k, v in enumerate(after72) if (v - c[j]) / c[j] >= BOUNCE), None)
            # the owner buys at the trigger (i), not at the bottom: did the trigger price get +1.5% back?
            ent = c[i]
            hit = next((k for k, v in enumerate(c[i + 1:i + 24 * 14]) if (v - ent) / ent >= BOUNCE), None)
            events.append({
                "t": t0 + i * H, "t_bottom": t0 + j * H, "window_h": w, "move": pct(r),
                "extra_drop_after_trigger": pct((c[j] - c[i]) / c[i]),
                "bounce_24h": pct(b24), "bounce_72h": pct(b72), "hours_to_bounce": hrs,
                "entry_recovered_h": None if hit is None else hit + 1,
            })
        else:
            events.append({"t": t0 + i * H, "window_h": w, "move": pct(r)})
    return events


# ---- 2 & 3. reactions and precursors --------------------------------------------------
def reactions_and_precursors(items, price, dips_by_sym):
    t0, c = price["BTC"]
    n = len(c)
    dip_hours = sorted(e["t"] for e in dips_by_sym.get("BTC", []))
    # base rate: share of all hours followed by a BTC dip within PRE_WINDOW
    def dip_within(ts):
        lo, hi = 0, len(dip_hours)
        while lo < hi:
            m = (lo + hi) // 2
            if dip_hours[m] <= ts:
                lo = m + 1
            else:
                hi = m
        return lo < len(dip_hours) and dip_hours[lo] - ts <= PRE_WINDOW
    sample = range(0, n, 3)
    base = sum(dip_within(t0 + k * H) for k in sample) / max(1, len(sample))

    groups = {}
    for it in items:
        ts = it.get("ts")
        if not ts or ts < t0 or ts > t0 + (n - 25) * H:
            continue
        i = idx_at(t0, n, ts)
        if i is None:
            continue
        r1, r4, r24 = ret(c, i, 1), ret(c, i, 4), ret(c, i, 24)
        hit = dip_within(ts)
        src_name = source_key(it)
        kws = keywords_of(it)
        keys = ([("source", src_name)] + [("topic", t) for t in it.get("tags", []) if t not in SYMS]
                + [("keyword", k) for k in kws] + [("combo", "%s · %s" % (src_name, k)) for k in kws])
        for kk in keys:
            g = groups.setdefault(kk, {"ts": [], "r1": [], "r4": [], "r24": [], "hits": []})
            g["ts"].append(ts)
            for name, v in (("r1", r1), ("r4", r4), ("r24", r24)):
                if v is not None:
                    g[name].append(v)
            g["hits"].append(1 if hit else 0)

    reactions, precursors = [], []
    for (kind, name), g in groups.items():
        cnt = len(g["hits"])
        if cnt < MIN_N:
            continue
        med = lambda xs: pct(st.median(xs), 2) if xs else None  # noqa: E731
        big = [abs(x) >= 0.02 for x in g["r4"]]
        reactions.append({
            "kind": kind, "name": name, "n": cnt,
            "median_1h": med(g["r1"]), "median_4h": med(g["r4"]), "median_24h": med(g["r24"]),
            "share_down_4h": pct(sum(1 for x in g["r4"] if x < 0) / len(g["r4"])) if g["r4"] else None,
            "share_big_move_4h": pct(sum(big) / len(big)) if big else None,
        })
        k = sum(g["hits"])
        half = cnt // 2
        k1, k2 = sum(g["hits"][:half]), sum(g["hits"][half:])
        rate = k / cnt
        precursors.append({
            "kind": kind, "name": name, "n": cnt, "dips_followed": k,
            "hit_rate": pct(rate), "base_rate": pct(base), "lift": round(rate / base, 2) if base else None,
            "hit_rate_low": pct(wilson_low(k, cnt)),
            "older_half": pct(k1 / half) if half else None,
            "newer_half": pct(k2 / (cnt - half)) if cnt - half else None,
            # "credible" only if even the pessimistic estimate beats chance AND it held in both halves
            "credible": bool(base and wilson_low(k, cnt) > base and half and
                             k1 / half > base and k2 / (cnt - half) > base),
        })
    reactions.sort(key=lambda r: -r["n"])
    precursors.sort(key=lambda p: (-(p["credible"]), -(p["lift"] or 0)))
    return reactions, precursors, base


# ---- 4. analogs ------------------------------------------------------------------------
def analogs():
    d = load_json(path("prices", "BTC_1d.json"))
    fng = load_json(path("sentiment", "fng_daily.json"), []) or []
    if not d or not d.get("c") or len(fng) < 60:
        return None
    t0, c = d["t0"], d["c"]
    fmap = {(r[0] // 86400) * 86400: r[1] for r in fng}

    def state(i):
        day = t0 + i * 86400
        if i < 200 or day not in fmap:
            return None
        ma200 = sum(c[i - 200:i]) / 200
        return [fmap[day] / 100.0, (c[i] - c[i - 7]) / c[i - 7], (c[i] - c[i - 30]) / c[i - 30], c[i] / ma200 - 1]
    last = len(c) - 1
    now = state(last)
    if not now:
        return None
    scale = [0.25, 0.10, 0.25, 0.40]
    cands = []
    for i in range(200, last - 30):
        s = state(i)
        if not s:
            continue
        dist = math.sqrt(sum(((a - b) / w) ** 2 for a, b, w in zip(s, now, scale)))
        cands.append((dist, i))
    cands.sort()
    picks, used = [], []
    for dist, i in cands:
        if any(abs(i - u) < 20 for u in used):
            continue          # avoid near-duplicate days from the same episode
        used.append(i)
        f7 = (c[i + 7] - c[i]) / c[i]
        f30 = (c[i + 30] - c[i]) / c[i]
        picks.append({"date": iso(t0 + i * 86400)[:10], "distance": round(dist, 3),
                      "fng": fmap.get(t0 + i * 86400), "fwd_7d": pct(f7), "fwd_30d": pct(f30)})
        if len(picks) == 10:
            break
    f7s = [p["fwd_7d"] for p in picks]
    f30s = [p["fwd_30d"] for p in picks]
    return {
        "today": {"fng": round(now[0] * 100), "ret_7d": pct(now[1]), "ret_30d": pct(now[2]), "vs_200d": pct(now[3])},
        "analogs": picks,
        "median_fwd_7d": round(st.median(f7s), 1) if f7s else None,
        "median_fwd_30d": round(st.median(f30s), 1) if f30s else None,
        "share_up_30d": pct(sum(1 for x in f30s if x > 0) / len(f30s)) if f30s else None,
    }


# ---- 5. bounce odds by regime ---------------------------------------------------------------
def regime_stats(dips):
    d = load_json(path("prices", "BTC_1d.json"))
    fng = load_json(path("sentiment", "fng_daily.json"), []) or []
    fmap = {(r[0] // 86400) * 86400: r[1] for r in fng}
    out = {}
    for sym, evs in dips.items():
        buckets = {}
        for e in evs:
            day = (e["t"] // 86400) * 86400
            f = fmap.get(day) or fmap.get(day - 86400)
            mood = None if f is None else ("fear" if f < 45 else "greed" if f > 55 else "neutral")
            trend = None
            if d and d.get("c"):
                i = (day - d["t0"]) // 86400
                if 200 <= i < len(d["c"]):
                    trend = "uptrend" if d["c"][i] > sum(d["c"][i - 200:i]) / 200 else "downtrend"
            for key in ("all", mood and "mood:" + mood, trend and "trend:" + trend):
                if key:
                    buckets.setdefault(key, []).append(e)
        out[sym] = {}
        for key, evs2 in buckets.items():
            rec = [e["entry_recovered_h"] for e in evs2]
            got = [r for r in rec if r is not None]
            out[sym][key] = {
                "n": len(evs2),
                "recovered_rate": pct(len(got) / len(evs2)),
                "median_hours": st.median(got) if got else None,
                "within_24h": pct(sum(1 for r in got if r <= 24) / len(evs2)),
                "median_extra_drop": round(st.median([e["extra_drop_after_trigger"] for e in evs2]), 2),
            }
    return out


# ---- main ---------------------------------------------------------------------------
def main():
    t_start = now_ts()
    price = {s: load_hourly(s) for s in SYMS}
    if not price.get("BTC"):
        log("analyze: no hourly prices yet (run backfill)")
        return
    dips, pumps = {}, {}
    for s in SYMS:
        if price.get(s):
            dips[s] = find_events(*price[s], sign=-1)
            pumps[s] = find_events(*price[s], sign=+1)
    items = load_items()
    reactions, precursors, base = reactions_and_precursors(items, price, dips)
    regimes = regime_stats(dips)
    ana = analogs()

    out = path("analysis")
    save_json(os.path.join(out, "events.json"), {"dips": dips, "pumps": pumps, "rules": {
        "dip_thresholds": {str(k): v for k, v in DIP.items()}, "bounce": BOUNCE}})
    save_json(os.path.join(out, "reactions.json"), reactions)
    save_json(os.path.join(out, "precursors.json"), {"base_rate": pct(base), "window_hours": PRE_WINDOW // H,
                                                     "rows": precursors})
    save_json(os.path.join(out, "regimes.json"), regimes)
    if ana:
        save_json(os.path.join(out, "analogs.json"), ana)

    # plain-language findings for the app and for Claude's briefing
    ins = []
    for s in SYMS:
        r = regimes.get(s, {}).get("all")
        if r and r["n"]:
            ins.append("%s: %d sharp dips in the stored history; buying at the trigger got +1.5%% back within 14 days in %s%% of cases "
                       "(median %s h), %s%% within 24 h. Typical extra drop after the trigger: %s%%."
                       % (s, r["n"], r["recovered_rate"], r["median_hours"], r["within_24h"], r["median_extra_drop"]))
        for mood in ("fear", "greed"):
            m = regimes.get(s, {}).get("mood:" + mood)
            if m and m["n"] >= 5:
                ins.append("%s dips during %s: recovered %s%% of the time (n=%d)." % (s, mood, m["recovered_rate"], m["n"]))
    cred = [p for p in precursors if p["credible"]][:5]
    for p in cred:
        ins.append("Precursor: %s '%s' was followed by a BTC dip within %dh %s%% of the time vs %s%% by chance "
                   "(lift %sx, n=%d, held in both halves of the data)."
                   % (p["kind"], p["name"], PRE_WINDOW // H, p["hit_rate"], p["base_rate"], p["lift"], p["n"]))
    if not cred:
        ins.append("No source or topic yet passes the precursor test (beats chance with a safety margin in both halves). "
                   "This is expected early on; it sharpens as the archive grows.")
    for r in [x for x in reactions if x["kind"] == "source"][:4]:
        ins.append("After %s items (n=%d): BTC median move %s%% in 4h, big (2%%+) moves %s%% of the time."
                   % (r["name"], r["n"], r["median_4h"], r["share_big_move_4h"]))
    if ana:
        ins.append("Today's market state most resembles %s; 30 days after those days BTC's median move was %s%% "
                   "(up in %s%% of them)." % (", ".join(a["date"] for a in ana["analogs"][:3]),
                                                ana["median_fwd_30d"], ana["share_up_30d"]))
    save_json(os.path.join(out, "insights.json"), {"generated_at": iso(), "generated_ts": now_ts(),
                                                   "items_analysed": len(items), "insights": ins}, pretty=True)
    log("analyze: %d items, %d BTC dips, %d credible precursors in %ds"
        % (len(items), len(dips.get("BTC", [])), len(cred), now_ts() - t_start))


if __name__ == "__main__":
    main()
