"""Uniform price series ({t0, step, c:[closes]}) and the composite sentiment index."""
from common import SYMS, load_json, log, now_ts, path, save_json
from sources import coinbase_candles

HOUR, DAY = 3600, 86400
KEEP = {HOUR: 2 * 365 * 24, DAY: 20 * 365}   # hourly: 2 years, daily: everything


def series_file(sym, step):
    return path("prices", "%s_%s.json" % (sym, "1h" if step == HOUR else "1d"))


def update_series(sym, step, first_start=None):
    """Extend the stored series with completed candles up to now. Forward-fills gaps."""
    f = series_file(sym, step)
    s = load_json(f)
    now = now_ts()
    last_complete = (now // step) * step - step           # start of the last *finished* candle
    if s and s.get("c"):
        start = s["t0"] + step * len(s["c"])
    else:
        start = first_start if first_start else last_complete - step * 299
        start = (start // step) * step
        s = {"t0": start, "step": step, "c": []}
    if start > last_complete:
        return s
    rows = coinbase_candles(sym, step, start, last_complete + step)
    if not rows and not s["c"]:
        log("no candles for", sym, step)
        return s
    by_ts = dict(rows)
    if not s["c"]:
        first = rows[0][0]
        s["t0"] = first
        start = first
    last = s["c"][-1] if s["c"] else rows[0][1]
    t = start
    while t <= last_complete:
        v = by_ts.get(t, last)
        s["c"].append(round(v, 6))
        last = v
        t += step
    extra = len(s["c"]) - KEEP[step]
    if extra > 0:
        s["c"] = s["c"][extra:]
        s["t0"] += extra * step
    save_json(f, s)
    return s


def pct_change(s, lookback_steps):
    c = (s or {}).get("c") or []
    if len(c) <= lookback_steps:
        return None
    a, b = c[-1 - lookback_steps], c[-1]
    return (b - a) / a if a else None


# ---- composite sentiment -------------------------------------------------------
WEIGHTS = {"fng": 0.35, "momentum": 0.20, "news_tone": 0.15, "crowding": 0.15, "ai_calm": 0.15}
LABELS = [(25, "Extreme fear"), (45, "Fear"), (56, "Neutral"), (76, "Greed"), (101, "Extreme greed")]


def clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


def label(v):
    for lim, name in LABELS:
        if v < lim:
            return name
    return LABELS[-1][1]


def components(fng=None, btc_7d=None, tone_24h=None, funding_avg_h=None, ai_risk=None):
    """Each component 0..100, higher = greedier / calmer. None when unavailable."""
    comp = {}
    if fng is not None:
        comp["fng"] = float(fng)
    if btc_7d is not None:
        comp["momentum"] = clamp(50 + btc_7d * 250)                 # +/-20% in 7d -> 100/0
    if tone_24h is not None:
        comp["news_tone"] = clamp((tone_24h + 3.0) / 6.0 * 100)      # GDELT tone -3..+3
    if funding_avg_h is not None:
        comp["crowding"] = clamp(50 + funding_avg_h * 24 * 365 * 125)  # annualised +/-40%
    if ai_risk is not None:
        comp["ai_calm"] = clamp(100 - float(ai_risk))
    return comp


def composite(comp):
    tot = sum(WEIGHTS[k] for k in comp)
    if not tot:
        return None
    return round(sum(comp[k] * WEIGHTS[k] for k in comp) / tot, 1)
